<?php
// ============================================================
//  register.php
// ============================================================
require_once 'config.php';
redirectIfLoggedIn();

$errors = [];
$old    = ['full_name' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ── Collect & trim inputs ──────────────────────────────
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email']     ?? '');
    $password  = $_POST['password']       ?? '';
    $confirm   = $_POST['confirm']        ?? '';

    $old = ['full_name' => $full_name, 'email' => $email];

    // ── Validate ───────────────────────────────────────────
    if ($full_name === '') {
        $errors['full_name'] = 'Please enter your full name.';
    } elseif (strlen($full_name) > 100) {
        $errors['full_name'] = 'Name must be 100 characters or fewer.';
    }

    if ($email === '') {
        $errors['email'] = 'Please enter your email address.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address.';
    }

    if (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters.';
    }

    if ($password !== $confirm) {
        $errors['confirm'] = 'Passwords do not match.';
    }

    // ── Check for duplicate email ──────────────────────────
    if (empty($errors)) {
        $pdo  = getDB();
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors['email'] = 'That email is already registered. Try logging in.';
        }
    }

    // ── Insert user ────────────────────────────────────────
    if (empty($errors)) {
        $pdo  = getDB();
        $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

        $stmt = $pdo->prepare(
            'INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)'
        );
        $stmt->execute([$full_name, $email, $hash]);
        $userId = (int) $pdo->lastInsertId();

        // ── Seed default classes for new user ──────────────
        $defaultClasses = [
            ['Introduction to Programming', 'CS101',   '#5B9BD5', ''],
            ['Mathematics I',               'MATH101',  '#8B7EC8', ''],
            ['English Communication',       'ENG101',   '#6A8F6E', ''],
        ];
        $ins = $pdo->prepare(
            'INSERT INTO classes (user_id, name, code, color, prof) VALUES (?, ?, ?, ?, ?)'
        );
        foreach ($defaultClasses as $c) {
            $ins->execute([$userId, $c[0], $c[1], $c[2], $c[3]]);
        }

        // ── Log in immediately ─────────────────────────────
        startSecureSession();
        session_regenerate_id(true);
        $_SESSION['user_id']   = $userId;
        $_SESSION['user_name'] = $full_name;

        header('Location: index.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account — StudyFlow</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;500;600;700;800&family=Fraunces:opsz,wght@9..144,400;9..144,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.47.0/tabler-icons.min.css">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html { font-size: 15px; }

  body {
    font-family: 'Nunito', sans-serif;
    background: #FEF9F3;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
  }

  /* Background blobs */
  body::before {
    content: '';
    position: fixed; top: -80px; right: -80px;
    width: 360px; height: 360px; border-radius: 50%;
    background: radial-gradient(circle, #FFE4CC 0%, transparent 70%);
    pointer-events: none;
  }
  body::after {
    content: '';
    position: fixed; bottom: -60px; left: -60px;
    width: 300px; height: 300px; border-radius: 50%;
    background: radial-gradient(circle, #EBF5EC 0%, transparent 70%);
    pointer-events: none;
  }

  .card {
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 16px 48px rgba(45,36,22,0.12);
    width: 100%;
    max-width: 460px;
    padding: 40px 36px;
    position: relative;
    z-index: 1;
    animation: cardIn .35s cubic-bezier(.34,1.56,.64,1);
  }
  @keyframes cardIn { from { opacity:0; transform:translateY(20px) scale(.97); } to { opacity:1; transform:none; } }

  .logo-row {
    text-align: center;
    margin-bottom: 28px;
  }
  .logo-emoji { font-size: 36px; display: block; margin-bottom: 8px; }
  .logo-name {
    font-family: 'Fraunces', serif;
    font-size: 26px; font-weight: 600;
    color: #2D2416; letter-spacing: -0.4px;
  }
  .logo-sub { font-size: 13px; color: #9A8872; margin-top: 4px; }

  h1 {
    font-family: 'Fraunces', serif;
    font-size: 20px; font-weight: 600;
    color: #2D2416; margin-bottom: 6px;
  }
  .subtitle { font-size: 13px; color: #9A8872; margin-bottom: 24px; }

  .form-group { margin-bottom: 16px; }
  .form-label {
    display: block; font-size: 11.5px; font-weight: 800;
    color: #5C4D3A; letter-spacing: .05em;
    text-transform: uppercase; margin-bottom: 6px;
  }

  .input-wrap { position: relative; }
  .input-icon {
    position: absolute; left: 13px; top: 50%; transform: translateY(-50%);
    color: #9A8872; font-size: 17px; pointer-events: none;
  }
  .form-input {
    width: 100%; padding: 11px 13px 11px 40px;
    border: 1.5px solid rgba(45,36,22,.15);
    border-radius: 10px; font-family: 'Nunito', sans-serif;
    font-size: 14px; color: #2D2416; background: #FEF9F3;
    outline: none; transition: all .15s;
  }
  .form-input:focus {
    border-color: #D96B3F; background: #fff;
    box-shadow: 0 0 0 3px rgba(217,107,63,.12);
  }
  .form-input.is-error { border-color: #D4607A; }

  .toggle-pw {
    position: absolute; right: 13px; top: 50%; transform: translateY(-50%);
    background: none; border: none; cursor: pointer;
    color: #9A8872; font-size: 17px; padding: 0; transition: color .15s;
  }
  .toggle-pw:hover { color: #D96B3F; }

  .field-error {
    font-size: 12px; color: #D4607A; font-weight: 600;
    margin-top: 5px; display: flex; align-items: center; gap: 4px;
  }

  .strength-bar {
    height: 4px; border-radius: 99px; background: #F5ECD8;
    margin-top: 8px; overflow: hidden;
  }
  .strength-fill { height: 100%; border-radius: 99px; transition: width .3s, background .3s; width: 0%; }

  .strength-label { font-size: 11px; color: #9A8872; margin-top: 4px; }

  .submit-btn {
    width: 100%; padding: 13px;
    background: #D96B3F; color: white; border: none;
    border-radius: 10px; font-family: 'Nunito', sans-serif;
    font-size: 15px; font-weight: 800; cursor: pointer;
    transition: all .18s; margin-top: 8px;
    display: flex; align-items: center; justify-content: center; gap: 8px;
    box-shadow: 0 4px 14px rgba(217,107,63,.35);
  }
  .submit-btn:hover { background: #9E3D18; transform: translateY(-1px); box-shadow: 0 6px 18px rgba(217,107,63,.4); }
  .submit-btn:active { transform: none; }

  .divider { text-align: center; color: #9A8872; font-size: 12.5px; margin: 18px 0; position: relative; }
  .divider::before, .divider::after {
    content: ''; position: absolute; top: 50%;
    width: 40%; height: 1px; background: rgba(45,36,22,.1);
  }
  .divider::before { left: 0; }
  .divider::after  { right: 0; }

  .login-link {
    text-align: center; font-size: 13.5px; color: #5C4D3A;
  }
  .login-link a { color: #D96B3F; font-weight: 700; text-decoration: none; }
  .login-link a:hover { text-decoration: underline; }

  .alert-error {
    background: #FDEEF2; border: 1.5px solid #F5B8C4; border-radius: 10px;
    padding: 12px 14px; margin-bottom: 18px;
    font-size: 13px; color: #9B2335;
    display: flex; align-items: flex-start; gap: 8px;
  }

  .terms {
    font-size: 11.5px; color: #9A8872; text-align: center; margin-top: 16px; line-height: 1.5;
  }
  .terms a { color: #D96B3F; text-decoration: none; }
</style>
</head>
<body>

<div class="card">

  <div class="logo-row">
    <span class="logo-emoji">📚</span>
    <div class="logo-name">StudyFlow</div>
    <div class="logo-sub">Your academic companion</div>
  </div>

  <h1>Create your account</h1>
  <p class="subtitle">Join thousands of students staying on top of their coursework.</p>

  <?php if (!empty($errors) && !isset($errors['full_name']) && !isset($errors['email']) && !isset($errors['password']) && !isset($errors['confirm'])): ?>
  <div class="alert-error">
    <i class="ti ti-alert-circle"></i>
    <span>Something went wrong. Please check your details and try again.</span>
  </div>
  <?php endif; ?>

  <form method="POST" action="register.php" novalidate>

    <!-- Full name -->
    <div class="form-group">
      <label class="form-label" for="full_name">Full name</label>
      <div class="input-wrap">
        <i class="ti ti-user input-icon"></i>
        <input class="form-input <?= isset($errors['full_name']) ? 'is-error' : '' ?>"
               type="text" id="full_name" name="full_name"
               value="<?= h($old['full_name']) ?>"
               placeholder="e.g. Ahmad Razif"
               autocomplete="name" required>
      </div>
      <?php if (isset($errors['full_name'])): ?>
        <div class="field-error"><i class="ti ti-alert-circle"></i><?= h($errors['full_name']) ?></div>
      <?php endif; ?>
    </div>

    <!-- Email -->
    <div class="form-group">
      <label class="form-label" for="email">Email address</label>
      <div class="input-wrap">
        <i class="ti ti-mail input-icon"></i>
        <input class="form-input <?= isset($errors['email']) ? 'is-error' : '' ?>"
               type="email" id="email" name="email"
               value="<?= h($old['email']) ?>"
               placeholder="you@university.edu.my"
               autocomplete="email" required>
      </div>
      <?php if (isset($errors['email'])): ?>
        <div class="field-error"><i class="ti ti-alert-circle"></i><?= h($errors['email']) ?></div>
      <?php endif; ?>
    </div>

    <!-- Password -->
    <div class="form-group">
      <label class="form-label" for="password">Password</label>
      <div class="input-wrap">
        <i class="ti ti-lock input-icon"></i>
        <input class="form-input <?= isset($errors['password']) ? 'is-error' : '' ?>"
               type="password" id="password" name="password"
               placeholder="At least 8 characters"
               autocomplete="new-password" oninput="checkStrength(this.value)" required>
        <button type="button" class="toggle-pw" onclick="togglePw('password', this)" tabindex="-1">
          <i class="ti ti-eye"></i>
        </button>
      </div>
      <div class="strength-bar"><div class="strength-fill" id="strength-fill"></div></div>
      <div class="strength-label" id="strength-label"></div>
      <?php if (isset($errors['password'])): ?>
        <div class="field-error"><i class="ti ti-alert-circle"></i><?= h($errors['password']) ?></div>
      <?php endif; ?>
    </div>

    <!-- Confirm password -->
    <div class="form-group">
      <label class="form-label" for="confirm">Confirm password</label>
      <div class="input-wrap">
        <i class="ti ti-lock-check input-icon"></i>
        <input class="form-input <?= isset($errors['confirm']) ? 'is-error' : '' ?>"
               type="password" id="confirm" name="confirm"
               placeholder="Re-enter your password"
               autocomplete="new-password" required>
        <button type="button" class="toggle-pw" onclick="togglePw('confirm', this)" tabindex="-1">
          <i class="ti ti-eye"></i>
        </button>
      </div>
      <?php if (isset($errors['confirm'])): ?>
        <div class="field-error"><i class="ti ti-alert-circle"></i><?= h($errors['confirm']) ?></div>
      <?php endif; ?>
    </div>

    <button type="submit" class="submit-btn">
      <i class="ti ti-user-plus"></i> Create account
    </button>
  </form>

  <div class="divider">or</div>
  <div class="login-link">Already have an account? <a href="login.php">Sign in</a></div>

  <p class="terms">By registering you agree to our <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.</p>
</div>

<script>
function togglePw(id, btn) {
  const input = document.getElementById(id);
  const icon  = btn.querySelector('i');
  if (input.type === 'password') {
    input.type = 'text';
    icon.className = 'ti ti-eye-off';
  } else {
    input.type = 'password';
    icon.className = 'ti ti-eye';
  }
}

function checkStrength(val) {
  const fill  = document.getElementById('strength-fill');
  const label = document.getElementById('strength-label');
  let score = 0;
  if (val.length >= 8)  score++;
  if (val.length >= 12) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;

  const map = [
    { w: '0%',   bg: 'transparent', txt: '' },
    { w: '25%',  bg: '#D4607A',     txt: '🔴 Weak' },
    { w: '50%',  bg: '#E09B2D',     txt: '🟡 Fair' },
    { w: '75%',  bg: '#5B9BD5',     txt: '🔵 Good' },
    { w: '100%', bg: '#6A8F6E',     txt: '🟢 Strong' },
  ];
  const s = Math.min(score, 4);
  fill.style.width      = map[s].w;
  fill.style.background = map[s].bg;
  label.textContent     = map[s].txt;
}
</script>
</body>
</html>
