-- ============================================================
--  StudyFlow Database
--  Import this file in phpMyAdmin or run:
--  mysql -u root -p < studyflow.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS studyflow
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE studyflow;

-- ------------------------------------------------------------
-- Table: users
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id           INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  full_name    VARCHAR(100)    NOT NULL,
  email        VARCHAR(180)    NOT NULL UNIQUE,
  password     VARCHAR(255)    NOT NULL,          -- bcrypt hash
  created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: classes
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS classes (
  id           INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  user_id      INT UNSIGNED    NOT NULL,
  name         VARCHAR(120)    NOT NULL,
  code         VARCHAR(20)     NOT NULL,
  color        VARCHAR(10)     NOT NULL DEFAULT '#5B9BD5',
  prof         VARCHAR(100)    DEFAULT NULL,
  created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_classes_user
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: tasks
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tasks (
  id           INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  user_id      INT UNSIGNED    NOT NULL,
  class_id     INT UNSIGNED    DEFAULT NULL,
  title        VARCHAR(255)    NOT NULL,
  type         ENUM('assignment','quiz','project','exam','reading','lab','presentation','other')
                               NOT NULL DEFAULT 'assignment',
  due_date     DATE            NOT NULL,
  priority     ENUM('high','medium','low') NOT NULL DEFAULT 'medium',
  notes        TEXT            DEFAULT NULL,
  is_done      TINYINT(1)      NOT NULL DEFAULT 0,
  created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_tasks_user
    FOREIGN KEY (user_id)  REFERENCES users(id)   ON DELETE CASCADE,
  CONSTRAINT fk_tasks_class
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Indexes for faster look-ups
-- ------------------------------------------------------------
CREATE INDEX idx_tasks_user_due  ON tasks  (user_id, due_date);
CREATE INDEX idx_tasks_user_done ON tasks  (user_id, is_done);
CREATE INDEX idx_classes_user    ON classes(user_id);
