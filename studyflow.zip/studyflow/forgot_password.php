<?php
// ============================================================
//  forgot_password.php  —  Two-step password reset
//  Step 1: Verify Gmail + full name match
//  Step 2: Enter & confirm new password
// ============================================================
require_once 'config.php';
redirectIfLoggedIn();

// ── State ────────────────────────────────────────────────────
$step    = 1;          // 1 = verify identity, 2 = set new password
$error   = '';
$success = '';
$old     = ['email' => '', 'full_name' => ''];

// ── Step 1 — Verify Gmail + name ─────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify'])) {

    $email     = trim($_POST['email']     ?? '');
    $full_name = trim($_POST['full_name'] ?? '');

    $old['email']     = $email;
    $old['full_name'] = $full_name;

    // Presence checks
    if ($email === '' || $full_name === '') {
        $error = 'Please enter both your Gmail address and your full name.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid Gmail address.';

    } elseif (!str_ends_with(strtolower($email), '@gmail.com')) {
        $error = 'Only Gmail addresses (@gmail.com) are accepted.';

    } else {
        // Look up the user — compare email AND full_name (case-insensitive)
        $pdo  = getDB();
        $stmt = $pdo->prepare(
            'SELECT id FROM users
              WHERE email = ?
                AND LOWER(full_name) = LOWER(?)'
        );
        $stmt->execute([$email, $full_name]);
        $user = $stmt->fetch();

        if ($user) {
            // Identity verified — advance to step 2
            $step = 2;
            // Store verified identity in session so step-2 POST knows who to update
            startSecureSession();
            $_SESSION['reset_user_id'] = (int) $user['id'];
            $_SESSION['reset_email']   = $email;
        } else {
            // Generic message — don't reveal whether email or name was wrong
            $error = 'No account found matching that Gmail address and name. Please check and try again.';
        }
    }
}

// ── Step 2 — Save new password ───────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset'])) {

    startSecureSession();

    $new_password     = $_POST['new_password']     ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Guard: session must have a verified user from step 1
    if (empty($_SESSION['reset_user_id'])) {
        $error = 'Session expired. Please start again.';
        $step  = 1;

    } elseif ($new_password === '' || $confirm_password === '') {
        $error = 'Please fill in both password fields.';
        $step  = 2;

    } elseif (strlen($new_password) < 8) {
        $error = 'Password must be at least 8 characters.';
        $step  = 2;

    } elseif ($new_password !== $confirm_password) {
        $error = 'Passwords do not match. Please try again.';
        $step  = 2;

    } else {
        $pdo  = getDB();
        $hash = password_hash($new_password, PASSWORD_BCRYPT);

        $stmt = $pdo->prepare('UPDATE users SET password = ? WHERE id = ?');
        $stmt->execute([$hash, $_SESSION['reset_user_id']]);

        // Clear reset tokens from session
        unset($_SESSION['reset_user_id'], $_SESSION['reset_email']);

        $success = 'Your password has been updated! You can now sign in with your new password.';
        $step    = 1; // Send back to step-1 view (success banner shown, form hidden)
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password — StudyFlow</title>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.47.0/tabler-icons.min.css">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { font-size: 15px; }

body {
    font-family: 'Times New Roman', Times, serif;
    background: #FEF9F3;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
}

body::before {
    content: '';
    position: fixed; top: -80px; right: -80px;
    width: 360px; height: 360px; border-radius: 50%;
    background: radial-gradient(circle, #FFE4CC 0%, transparent 70%);
    pointer-events: none;
}
body::after {
    content: '';
    position: fixed; bottom: -60px; left: -60px;
    width: 300px; height: 300px; border-radius: 50%;
    background: radial-gradient(circle, #EBF5EC 0%, transparent 70%);
    pointer-events: none;
}

.card {
    background: #fff;
    width: 100%;
    max-width: 430px;
    border-radius: 20px;
    padding: 40px 36px;
    box-shadow: 0 16px 48px rgba(45,36,22,0.12);
    position: relative;
    z-index: 1;
    animation: cardIn .35s cubic-bezier(.34,1.56,.64,1);
}
@keyframes cardIn {
    from { opacity: 0; transform: translateY(20px) scale(.97); }
    to   { opacity: 1; transform: none; }
}

.logo-row { text-align: center; margin-bottom: 26px; }
.logo-emoji { font-size: 36px; display: block; margin-bottom: 8px; }
.logo-name {
    font-family: 'Times New Roman', Times, serif;
    font-size: 28px;
    font-weight: 600;
    color: #2D2416;
}
.logo-sub { color: #9A8872; font-size: 13px; margin-top: 4px; }

/* Step indicator */
.steps {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0;
    margin-bottom: 26px;
}
.step-dot {
    width: 30px; height: 30px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 12px; font-weight: 800;
    background: rgba(45,36,22,.08);
    color: #9A8872;
    transition: all .2s;
}
.step-dot.active {
    background: #D96B3F;
    color: #fff;
    box-shadow: 0 3px 10px rgba(217,107,63,.35);
}
.step-dot.done {
    background: #10B981;
    color: #fff;
}
.step-line {
    width: 56px; height: 2px;
    background: rgba(45,36,22,.1);
}
.step-line.done { background: #10B981; }

h1 {
    font-family: 'Times New Roman', Times, serif;
    font-size: 20px;
    color: #2D2416;
    margin-bottom: 6px;
}
.subtitle {
    color: #9A8872;
    font-size: 13px;
    margin-bottom: 22px;
    line-height: 1.6;
}

.form-group { margin-bottom: 16px; }
.form-label {
    display: block;
    margin-bottom: 6px;
    font-size: 11.5px;
    font-weight: 800;
    color: #5C4D3A;
    text-transform: uppercase;
    letter-spacing: .05em;
}
.input-wrap { position: relative; }
.input-icon {
    position: absolute;
    left: 13px; top: 50%;
    transform: translateY(-50%);
    color: #9A8872; font-size: 17px;
    pointer-events: none;
}
.form-input {
    width: 100%;
    padding: 11px 13px 11px 40px;
    border-radius: 10px;
    border: 1.5px solid rgba(45,36,22,.15);
    background: #FEF9F3;
    font-family: 'Times New Roman', Times, serif;
    font-size: 14px;
    color: #2D2416;
    outline: none;
    transition: all .15s;
}
.form-input:focus {
    border-color: #D96B3F;
    background: #fff;
    box-shadow: 0 0 0 3px rgba(217,107,63,.12);
}
.toggle-pw {
    position: absolute; right: 13px; top: 50%; transform: translateY(-50%);
    background: none; border: none; cursor: pointer;
    color: #9A8872; font-size: 17px; padding: 0; transition: color .15s;
}
.toggle-pw:hover { color: #D96B3F; }

/* Password strength */
.strength-bar {
    height: 4px; border-radius: 2px;
    background: rgba(45,36,22,.08);
    margin-top: 8px; overflow: hidden;
}
.strength-fill {
    height: 100%; border-radius: 2px;
    width: 0%; transition: width .3s, background .3s;
}
.strength-label {
    font-size: 11px; color: #9A8872;
    margin-top: 4px; text-align: right;
}

.submit-btn {
    width: 100%;
    border: none;
    border-radius: 10px;
    background: #D96B3F;
    color: #fff;
    padding: 13px;
    font-family: 'Times New Roman', Times, serif;
    font-size: 15px;
    font-weight: 800;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    box-shadow: 0 4px 14px rgba(217,107,63,.35);
    transition: all .18s;
}
.submit-btn:hover  { background: #9E3D18; transform: translateY(-1px); }
.submit-btn:active { transform: none; }

.alert-error, .alert-success {
    border-radius: 10px;
    padding: 12px 14px;
    margin-bottom: 18px;
    font-size: 13px;
    display: flex; align-items: flex-start; gap: 8px;
}
.alert-error {
    background: #FDEEF2;
    border: 1.5px solid #F5B8C4;
    color: #9B2335;
    animation: shake .4s ease;
}
.alert-success {
    background: #ECFDF5;
    border: 1.5px solid #6EE7B7;
    color: #065F46;
}

@keyframes shake {
    0%,100% { transform: translateX(0); }
    20%,60%  { transform: translateX(-6px); }
    40%,80%  { transform: translateX(6px); }
}

.hint {
    font-size: 11.5px; color: #9A8872;
    margin-top: 5px; display: flex; align-items: center; gap: 5px;
}
.hint i { font-size: 13px; }

.back-link {
    margin-top: 20px;
    text-align: center;
    font-size: 13px;
}
.back-link a {
    color: #D96B3F;
    text-decoration: none;
    font-weight: 700;
}
.back-link a:hover { text-decoration: underline; }
</style>
</head>
<body>
<div class="card">

    <!-- Logo -->
    <div class="logo-row">
        <span class="logo-emoji">📚</span>
        <div class="logo-name">StudyFlow</div>
        <div class="logo-sub">Password Recovery</div>
    </div>

    <!-- Step indicator -->
    <div class="steps">
        <div class="step-dot <?= ($step >= 1 && $success === '') ? 'active' : ($success !== '' ? 'done' : 'done') ?>">
            <?php if ($success !== '' || $step === 2): ?>
                <i class="ti ti-check" style="font-size:14px"></i>
            <?php else: ?>1<?php endif; ?>
        </div>
        <div class="step-line <?= $step === 2 ? 'done' : '' ?>"></div>
        <div class="step-dot <?= $step === 2 ? 'active' : '' ?>">2</div>
    </div>

    <!-- ── Alerts ─────────────────────────────────── -->
    <?php if ($error !== ''): ?>
        <div class="alert-error">
            <i class="ti ti-alert-circle"></i>
            <span><?= h($error) ?></span>
        </div>
    <?php endif; ?>

    <?php if ($success !== ''): ?>
        <div class="alert-success">
            <i class="ti ti-circle-check"></i>
            <span><?= h($success) ?> <a href="login.php" style="color:#065F46;font-weight:800;">Sign in now →</a></span>
        </div>
    <?php endif; ?>

    <!-- ══════════════════════════════════════════════
         STEP 1 — Verify identity
    ══════════════════════════════════════════════ -->
    <?php if ($step === 1 && $success === ''): ?>

        <h1>Forgot your password?</h1>
        <p class="subtitle">Enter your registered Gmail address and the full name on your account. They must match exactly.</p>

        <form method="POST" action="forgot_password.php" novalidate>

            <div class="form-group">
                <label class="form-label" for="email">Gmail Address</label>
                <div class="input-wrap">
                    <i class="ti ti-mail input-icon"></i>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        class="form-input"
                        placeholder="yourname@gmail.com"
                        value="<?= h($old['email']) ?>"
                        autocomplete="email"
                        required
                        autofocus>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="full_name">Full Name</label>
                <div class="input-wrap">
                    <i class="ti ti-user input-icon"></i>
                    <input
                        type="text"
                        id="full_name"
                        name="full_name"
                        class="form-input"
                        placeholder="As registered on your account"
                        value="<?= h($old['full_name']) ?>"
                        autocomplete="name"
                        required>
                </div>
                <p class="hint"><i class="ti ti-info-circle"></i> Must match the name you used when registering.</p>
            </div>

            <button type="submit" name="verify" class="submit-btn">
                <i class="ti ti-shield-check"></i>
                Verify My Identity
            </button>
        </form>

    <?php endif; ?>

    <!-- ══════════════════════════════════════════════
         STEP 2 — Set new password
    ══════════════════════════════════════════════ -->
    <?php if ($step === 2): ?>

        <h1>Set a new password</h1>
        <p class="subtitle">Choose a strong password you haven't used before. Minimum 8 characters.</p>

        <form method="POST" action="forgot_password.php" novalidate>

            <div class="form-group">
                <label class="form-label" for="new_password">New Password</label>
                <div class="input-wrap">
                    <i class="ti ti-lock input-icon"></i>
                    <input
                        type="password"
                        id="new_password"
                        name="new_password"
                        class="form-input"
                        placeholder="At least 8 characters"
                        autocomplete="new-password"
                        oninput="updateStrength(this.value)"
                        required
                        autofocus>
                    <button type="button" class="toggle-pw" onclick="togglePw('new_password','eye1')" tabindex="-1">
                        <i class="ti ti-eye" id="eye1"></i>
                    </button>
                </div>
                <div class="strength-bar"><div class="strength-fill" id="strength-fill"></div></div>
                <div class="strength-label" id="strength-label"></div>
            </div>

            <div class="form-group">
                <label class="form-label" for="confirm_password">Confirm Password</label>
                <div class="input-wrap">
                    <i class="ti ti-lock-check input-icon"></i>
                    <input
                        type="password"
                        id="confirm_password"
                        name="confirm_password"
                        class="form-input"
                        placeholder="Re-enter your new password"
                        autocomplete="new-password"
                        required>
                    <button type="button" class="toggle-pw" onclick="togglePw('confirm_password','eye2')" tabindex="-1">
                        <i class="ti ti-eye" id="eye2"></i>
                    </button>
                </div>
            </div>

            <button type="submit" name="reset" class="submit-btn">
                <i class="ti ti-key"></i>
                Update Password
            </button>
        </form>

    <?php endif; ?>

    <div class="back-link">
        <a href="login.php"><i class="ti ti-arrow-left"></i> Back to Sign In</a>
    </div>

</div><!-- /.card -->

<script>
// Toggle password visibility
function togglePw(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon  = document.getElementById(iconId);
    if (input.type === 'password') {
        input.type    = 'text';
        icon.className = 'ti ti-eye-off';
    } else {
        input.type    = 'password';
        icon.className = 'ti ti-eye';
    }
}

// Basic password strength meter
function updateStrength(pw) {
    const fill  = document.getElementById('strength-fill');
    const label = document.getElementById('strength-label');
    if (!fill) return;

    let score = 0;
    if (pw.length >= 8)  score++;
    if (pw.length >= 12) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;

    const levels = [
        { pct: '0%',   color: '',        text: '' },
        { pct: '25%',  color: '#EF4444', text: 'Weak' },
        { pct: '50%',  color: '#F59E0B', text: 'Fair' },
        { pct: '75%',  color: '#3B82F6', text: 'Good' },
        { pct: '90%',  color: '#10B981', text: 'Strong' },
        { pct: '100%', color: '#10B981', text: 'Very strong' },
    ];

    const l = levels[Math.min(score, 5)];
    fill.style.width      = l.pct;
    fill.style.background = l.color;
    label.textContent     = l.text;
    label.style.color     = l.color || '#9A8872';
}
</script>
</body>
</html>
