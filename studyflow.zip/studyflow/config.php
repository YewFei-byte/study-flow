<?php
// ============================================================
//  config.php  —  Database connection (PDO)
//  Edit the four constants below to match your server.
// ============================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'studyflow');
define('DB_USER', 'root');        // change to your MySQL username
define('DB_PASS', '');            // change to your MySQL password
define('DB_CHAR', 'utf8mb4');

// Session lifetime (seconds)
define('SESSION_LIFETIME', 60 * 60 * 2); // 2 hours

// ── PDO connection ─────────────────────────────────────────
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=%s',
            DB_HOST, DB_NAME, DB_CHAR
        );
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            // Never expose raw DB errors to the browser in production
            error_log('DB connection failed: ' . $e->getMessage());
            die('Database connection error. Please try again later.');
        }
    }
    return $pdo;
}

// ── Session bootstrap ──────────────────────────────────────
function startSecureSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'secure'   => false,   // set to true if using HTTPS
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_start();
    }
}

// ── Auth guard ─────────────────────────────────────────────
// Call at the top of any page that requires login.
function requireLogin(): void {
    startSecureSession();
    if (empty($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

// ── Redirect if already logged in ─────────────────────────
function redirectIfLoggedIn(): void {
    startSecureSession();
    if (!empty($_SESSION['user_id'])) {
        header('Location: index.php');
        exit;
    }
}

// ── Sanitise output ────────────────────────────────────────
function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
