/* ═══════════════════════════════════════════
   CONSTANTS
═══════════════════════════════════════════ */
const CLASS_COLORS = [
  '#D96B3F','#E09B2D','#6A8F6E','#5B9BD5','#8B7EC8',
  '#D4607A','#2E86AB','#A23B72','#3D9970','#E76F51',
];

const TYPE_ICONS = {
  assignment:'ti-file-text', quiz:'ti-pencil', project:'ti-layout-board',
  exam:'ti-school', reading:'ti-book', lab:'ti-flask',
  presentation:'ti-presentation', other:'ti-dots',
};

/* ═══════════════════════════════════════════
   STATE
═══════════════════════════════════════════ */
const today = new Date();
today.setHours(0,0,0,0);

let state = {
  view:                 'all',
  typeFilter:           'all',
  sortBy:               'due',
  pickedColor:          CLASS_COLORS[0],
  pendingDeleteClassId: null,
  classes: (typeof DB_CLASSES !== 'undefined') ? DB_CLASSES : [],
  tasks:   (typeof DB_TASKS   !== 'undefined') ? DB_TASKS   : [],
};

/* ═══════════════════════════════════════════
   API
═══════════════════════════════════════════ */
async function apiPost(action, data) {
  try {
    const res = await fetch('api.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...data }),
    });
    return await res.json();
  } catch { return { ok: false }; }
}

/* ═══════════════════════════════════════════
   HELPERS
═══════════════════════════════════════════ */
function daysDiff(ds) {
  const d = new Date(ds); d.setHours(0,0,0,0);
  return Math.round((d - today) / 86400000);
}
function fmtDate(ds) {
  return new Date(ds).toLocaleDateString('en-MY',{month:'short',day:'numeric'});
}
function getClass(id) { return state.classes.find(c => String(c.id) === String(id)); }
function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function dueInfo(ds, done) {
  if (done) return null;
  const diff = daysDiff(ds);
  if (diff < 0)   return { text:`${Math.abs(diff)}d overdue`, cls:'due-overdue', status:'status-overdue' };
  if (diff === 0) return { text:'Due today!',         cls:'due-today',  status:'status-today'  };
  if (diff <= 3)  return { text:`Due ${fmtDate(ds)}`, cls:'due-soon',   status:'status-soon'   };
  return { text:fmtDate(ds), cls:'due-ok', status:'' };
}

/* ═══════════════════════════════════════════
   FILTER & SORT
═══════════════════════════════════════════ */
function filteredTasks() {
  let t = [...state.tasks];
  if      (state.view === 'all')      t = t.filter(x => !x.done);
  else if (state.view === 'today')    t = t.filter(x => !x.done && daysDiff(x.due)===0);
  else if (state.view === 'upcoming') t = t.filter(x => !x.done && daysDiff(x.due)>0 && daysDiff(x.due)<=7);
  else if (state.view === 'overdue')  t = t.filter(x => !x.done && daysDiff(x.due)<0);
  else if (state.view === 'done')     t = t.filter(x => x.done);
  else                                t = t.filter(x => String(x.subject)===String(state.view));

  if (state.typeFilter !== 'all') t = t.filter(x => x.type===state.typeFilter);

  const PRIO = {high:0,medium:1,low:2};
  if      (state.sortBy==='due')      t.sort((a,b)=>new Date(a.due)-new Date(b.due));
  else if (state.sortBy==='priority') t.sort((a,b)=>PRIO[a.priority]-PRIO[b.priority]);
  else if (state.sortBy==='subject')  t.sort((a,b)=>String(a.subject).localeCompare(String(b.subject)));
  else                                t.sort((a,b)=>b.createdAt-a.createdAt);
  return t;
}

/* ═══════════════════════════════════════════
   RENDER
═══════════════════════════════════════════ */
function render() {
  renderSidebar();
  renderCounts();
  renderStats();
  renderAlert();
  renderProgress();
  renderTasks();
}

function renderSidebar() {
  const el = document.getElementById('class-list');
  if (!state.classes.length) {
    el.innerHTML = `<div style="padding:8px 12px;font-size:12px;color:var(--ink-muted);font-style:italic">
      No classes yet — add one below!</div>`;
    return;
  }
  el.innerHTML = state.classes.map(c => {
    const cnt = state.tasks.filter(t => String(t.subject)===String(c.id) && !t.done).length;
    return `<div class="class-nav-item">
      <button class="class-nav-btn${String(state.view)===String(c.id)?' active':''}"
              onclick="setView('${c.id}',this);closeMobileMenu()">
        <span class="class-dot" style="background:${c.color}"></span>
        <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;text-align:left">${esc(c.name)}</span>
        ${cnt>0?`<span class="nav-count">${cnt}</span>`:''}
      </button>
      <button class="class-delete-btn" onclick="askDeleteClass('${c.id}','${esc(c.name)}')" title="Delete ${esc(c.name)}">
        <i class="ti ti-trash"></i>
      </button>
    </div>`;
  }).join('');
}

function renderCounts() {
  const inc = state.tasks.filter(t => !t.done);
  document.getElementById('cnt-all').textContent      = inc.length;
  document.getElementById('cnt-today').textContent    = inc.filter(t=>daysDiff(t.due)===0).length;
  document.getElementById('cnt-upcoming').textContent = inc.filter(t=>{const d=daysDiff(t.due);return d>0&&d<=7;}).length;
  document.getElementById('cnt-overdue').textContent  = inc.filter(t=>daysDiff(t.due)<0).length;
  document.getElementById('cnt-done').textContent     = state.tasks.filter(t=>t.done).length;
}

function renderStats() {
  const inc = state.tasks.filter(t=>!t.done);
  document.getElementById('s-total').textContent   = inc.length;
  document.getElementById('s-overdue').textContent = inc.filter(t=>daysDiff(t.due)<0).length;
  document.getElementById('s-soon').textContent    = inc.filter(t=>{const d=daysDiff(t.due);return d>=0&&d<=7;}).length;
  document.getElementById('s-done').textContent    = state.tasks.filter(t=>t.done).length;
}

function renderProgress() {
  const total = state.tasks.length;
  const done  = state.tasks.filter(t=>t.done).length;
  const pct   = total ? Math.round(done/total*100) : 0;
  document.getElementById('progress-fill').style.width     = pct+'%';
  document.getElementById('progress-pct').textContent      = pct+'%';
  document.getElementById('progress-fraction').textContent = `${done} / ${total} done`;
}

function renderAlert() {
  const inc  = state.tasks.filter(t=>!t.done);
  const ov   = inc.filter(t=>daysDiff(t.due)<0).length;
  const td   = inc.filter(t=>daysDiff(t.due)===0).length;
  const bar  = document.getElementById('alert-bar');
  const msgs = [];
  if (ov) msgs.push(`<strong>${ov} overdue</strong> assignment${ov>1?'s':''}`);
  if (td) msgs.push(`<strong>${td}</strong> due today`);
  if (msgs.length) {
    document.getElementById('alert-text').innerHTML = `Heads up! You have ${msgs.join(' and ')}. You got this! 💪`;
    bar.style.display = 'flex';
    // Show notification enable button if permission not yet granted
    const notifBtn = document.getElementById('notif-btn');
    if (notifBtn && 'Notification' in window && Notification.permission === 'default') {
      notifBtn.style.display = 'inline-block';
    }
  } else {
    bar.style.display = 'none';
  }
}

function renderTasks() {
  const root  = document.getElementById('tasks-root');
  const tasks = filteredTasks();
  if (!tasks.length) {
    const isClassView = !['all','today','upcoming','overdue','done'].includes(state.view);
    root.innerHTML = `<div class="empty-state">
      <span class="empty-emoji">${state.view==='done'?'🏆':'📋'}</span>
      <div class="empty-title">${state.view==='done'?'No completed tasks yet':'Nothing here yet'}</div>
      <div class="empty-sub">${state.view==='done'
        ?'Complete tasks to see them here.'
        :isClassView
          ?'No tasks for this class. Hit "New Assignment" to add one.'
          :'Add your first assignment using the button above.'
      }</div>
    </div>`;
    return;
  }

  if (state.view==='all' && state.sortBy==='due') {
    const groups = [
      {label:'⚠️ Overdue',     fn:t=>!t.done&&daysDiff(t.due)<0},
      {label:'📅 Due today',    fn:t=>!t.done&&daysDiff(t.due)===0},
      {label:'⏰ Due this week', fn:t=>!t.done&&daysDiff(t.due)>0&&daysDiff(t.due)<=7},
      {label:'🗓 Later',         fn:t=>!t.done&&daysDiff(t.due)>7},
    ];
    let html='';
    groups.forEach(g=>{
      const gt=tasks.filter(g.fn);
      if (!gt.length) return;
      html+=`<div class="section-heading">${g.label}</div>
             <div class="tasks-list">${gt.map(taskCard).join('')}</div>`;
    });
    root.innerHTML=html;
  } else {
    root.innerHTML=`<div class="tasks-list">${tasks.map(taskCard).join('')}</div>`;
  }
}

function taskCard(t) {
  const cls  = getClass(t.subject);
  const due  = dueInfo(t.due, t.done);
  const sclr = cls ? cls.color : '#888';
  const bg   = sclr+'22';
  const stCls= t.done?'status-done':(due?due.status:'');
  return `<div class="task-card ${stCls}" data-id="${t.id}">
    <div class="task-check ${t.done?'is-done':''}" onclick="toggleDone('${t.id}')" title="${t.done?'Mark as pending':'Mark as done'}"></div>
    <div class="task-body">
      <div class="task-row1">
        <span class="task-priority-dot p-${t.priority}"></span>
        <div class="task-title">${esc(t.title)}</div>
      </div>
      <div class="task-row2">
        ${cls?`<span class="tag" style="background:${bg};color:${sclr}">${esc(cls.code)}</span>`:''}
        <span class="tag tag-type"><i class="ti ${TYPE_ICONS[t.type]||'ti-file'}" style="font-size:12px"></i> ${t.type}</span>
        ${due
          ?`<span class="due-badge ${due.cls}"><i class="ti ti-calendar" style="font-size:12px"></i>${due.text}</span>`
          :`<span class="due-badge due-ok"><i class="ti ti-circle-check" style="font-size:12px"></i>Done</span>`
        }
      </div>
      ${t.notes?`<div class="task-note">${esc(t.notes)}</div>`:''}
    </div>
    <div class="task-actions">
      <button class="task-act-btn" onclick="openEditModal('${t.id}')" title="Edit"><i class="ti ti-pencil"></i></button>
      <button class="task-act-btn" onclick="deleteTask('${t.id}')" title="Delete"><i class="ti ti-trash"></i></button>
    </div>
  </div>`;
}

/* ═══════════════════════════════════════════
   ACTIONS
═══════════════════════════════════════════ */
function setView(v, btn) {
  state.view = v;
  document.querySelectorAll('.nav-btn,.class-nav-btn').forEach(b=>b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  const cls    = getClass(v);
  const TITLES = {all:'All Tasks',today:'Due Today',upcoming:'Upcoming (7 days)',overdue:'Overdue',done:'Completed'};
  const SUBS   = {
    all:'Your complete coursework list',
    today:"Everything due today — let's knock it out!",
    upcoming:'Assignments due in the next 7 days',
    overdue:'These need your attention ASAP 🚨',
    done:'Great work so far! 🎉',
  };
  document.getElementById('topbar-title').textContent = cls?cls.name:(TITLES[v]||v);
  document.getElementById('topbar-sub').textContent   = cls?(cls.prof?`Instructor: ${cls.prof}`:'Class tasks'):(SUBS[v]||'');
  render();
}

function setType(type, btn) {
  state.typeFilter = type;
  document.querySelectorAll('.filter-chip').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  renderTasks();
}

async function toggleDone(id) {
  const t = state.tasks.find(x=>String(x.id)===String(id));
  if (!t) return;
  t.done = !t.done;
  toast(t.done?'✅ Marked as complete!':'↩️ Task reopened');
  render();
  await apiPost('toggle_task',{id,is_done:t.done?1:0});
}

async function deleteTask(id) {
  state.tasks = state.tasks.filter(x=>String(x.id)!==String(id));
  toast('🗑️ Task deleted');
  render();
  await apiPost('delete_task',{id});
}

/* ═══════════════════════════════════════════
   DELETE CLASS
═══════════════════════════════════════════ */
function askDeleteClass(id, name) {
  state.pendingDeleteClassId = id;
  document.getElementById('confirm-class-name').textContent = name;
  openModal('confirm-modal');
}

async function confirmDeleteClass() {
  const id = state.pendingDeleteClassId;
  if (!id) return;
  state.tasks   = state.tasks.filter(t=>String(t.subject)!==String(id));
  state.classes = state.classes.filter(c=>String(c.id)!==String(id));
  if (String(state.view)===String(id)) setView('all',document.getElementById('nav-all'));
  closeModal('confirm-modal');
  toast('🗑️ Class deleted');
  render();
  await apiPost('delete_class',{id});
  state.pendingDeleteClassId = null;
}

/* ═══════════════════════════════════════════
   TASK MODAL
═══════════════════════════════════════════ */
function openTaskModal() {
  if (!state.classes.length) {
    toast('⚠️ Add a class first!');
    openClassModal();
    return;
  }
  const sel = document.getElementById('f-subject');
  sel.innerHTML = state.classes.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
  const d = new Date(today); d.setDate(d.getDate()+1);
  document.getElementById('f-date').value     = d.toISOString().split('T')[0];
  document.getElementById('f-date').min       = new Date(today).toISOString().split('T')[0];
  document.getElementById('f-title').value    = '';
  document.getElementById('f-notes').value    = '';
  document.getElementById('f-priority').value = 'medium';
  openModal('task-modal');
  setTimeout(()=>document.getElementById('f-title').focus(),300);
}

async function saveTask() {
  const title = document.getElementById('f-title').value.trim();
  const date  = document.getElementById('f-date').value;
  if (!title) { toast('⚠️ Please enter a task title'); return; }
  if (!date)  { toast('⚠️ Please pick a due date');    return; }
  const newTask = {
    id:'tmp-'+Date.now(), title,
    subject:  document.getElementById('f-subject').value,
    type:     document.getElementById('f-type').value,
    due:      date,
    priority: document.getElementById('f-priority').value,
    notes:    document.getElementById('f-notes').value.trim(),
    done:false, createdAt:Date.now(),
  };
  state.tasks.unshift(newTask);
  closeModal('task-modal');
  toast('📝 Assignment added!');
  render();
  const res = await apiPost('add_task',{
    class_id:newTask.subject, title:newTask.title, type:newTask.type,
    due_date:newTask.due, priority:newTask.priority, notes:newTask.notes,
  });
  if (res.ok && res.id) {
    const t = state.tasks.find(x=>x.id===newTask.id);
    if (t) t.id = String(res.id);
  }
}

/* ═══════════════════════════════════════════
   EDIT TASK MODAL
═══════════════════════════════════════════ */
function openEditModal(id) {
  const t = state.tasks.find(x => String(x.id) === String(id));
  if (!t) return;
  state.editingTaskId = id;

  // Populate subject dropdown
  const sel = document.getElementById('e-subject');
  sel.innerHTML = state.classes.map(c =>
    `<option value="${c.id}"${String(c.id)===String(t.subject)?' selected':''}>${c.name}</option>`
  ).join('');

  document.getElementById('e-title').value    = t.title;
  document.getElementById('e-type').value     = t.type;
  document.getElementById('e-date').value     = t.due;
  document.getElementById('e-priority').value = t.priority;
  document.getElementById('e-notes').value    = t.notes || '';
  openModal('edit-modal');
  setTimeout(() => document.getElementById('e-title').focus(), 300);
}

async function saveEdit() {
  const id    = state.editingTaskId;
  const title = document.getElementById('e-title').value.trim();
  const date  = document.getElementById('e-date').value;
  if (!title) { toast('⚠️ Please enter a task title'); return; }
  if (!date)  { toast('⚠️ Please pick a due date');    return; }

  const t = state.tasks.find(x => String(x.id) === String(id));
  if (!t) return;

  // Optimistic update
  t.title    = title;
  t.subject  = document.getElementById('e-subject').value;
  t.type     = document.getElementById('e-type').value;
  t.due      = date;
  t.priority = document.getElementById('e-priority').value;
  t.notes    = document.getElementById('e-notes').value.trim();

  closeModal('edit-modal');
  toast('✏️ Task updated!');
  render();

  await apiPost('edit_task', {
    id, class_id: t.subject, title: t.title, type: t.type,
    due_date: t.due, priority: t.priority, notes: t.notes,
  });
}

/* ═══════════════════════════════════════════
   BROWSER NOTIFICATIONS
═══════════════════════════════════════════ */
async function requestNotificationPermission() {
  if (!('Notification' in window)) return;
  if (Notification.permission === 'default') {
    await Notification.requestPermission();
  }
  scheduleNotifications();
}

function scheduleNotifications() {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;

  const inc = state.tasks.filter(t => !t.done);
  const overdue  = inc.filter(t => daysDiff(t.due) < 0);
  const dueToday = inc.filter(t => daysDiff(t.due) === 0);
  const dueSoon  = inc.filter(t => daysDiff(t.due) > 0 && daysDiff(t.due) <= 2);

  if (overdue.length) {
    new Notification('📚 StudyFlow — Overdue Tasks!', {
      body: `You have ${overdue.length} overdue assignment${overdue.length > 1 ? 's' : ''}. Don't fall behind!`,
      icon: 'https://cdn.jsdelivr.net/npm/@tabler/icons@2/icons/book.svg',
      tag: 'studyflow-overdue',
    });
  } else if (dueToday.length) {
    new Notification('📅 StudyFlow — Due Today', {
      body: `${dueToday.length} assignment${dueToday.length > 1 ? 's' : ''} due today: ${dueToday.map(t=>t.title).slice(0,2).join(', ')}`,
      icon: 'https://cdn.jsdelivr.net/npm/@tabler/icons@2/icons/calendar-event.svg',
      tag: 'studyflow-today',
    });
  } else if (dueSoon.length) {
    new Notification('⏰ StudyFlow — Coming Up Soon', {
      body: `${dueSoon.length} assignment${dueSoon.length > 1 ? 's' : ''} due in the next 2 days. Stay on top of it!`,
      tag: 'studyflow-soon',
    });
  }
}

/* ═══════════════════════════════════════════
   CLASS MODAL
═══════════════════════════════════════════ */
function openClassModal() {
  document.getElementById('c-name').value = '';
  document.getElementById('c-code').value = '';
  const profEl = document.getElementById('c-prof');
  if (profEl) profEl.value = '';
  state.pickedColor = CLASS_COLORS[0];
  document.getElementById('color-row').innerHTML = CLASS_COLORS.map(c=>
    `<div class="c-swatch${c===state.pickedColor?' picked':''}" style="background:${c}" onclick="pickColor('${c}',this)"></div>`
  ).join('');
  openModal('class-modal');
  setTimeout(()=>document.getElementById('c-name').focus(),300);
}

function pickColor(c, el) {
  state.pickedColor = c;
  document.querySelectorAll('.c-swatch').forEach(s=>s.classList.remove('picked'));
  el.classList.add('picked');
}

async function saveClass() {
  const name = document.getElementById('c-name').value.trim();
  if (!name) { toast('⚠️ Please enter a class name'); return; }
  const code = document.getElementById('c-code').value.trim() || name.slice(0,6).toUpperCase();
  const profEl = document.getElementById('c-prof');
  const prof = profEl ? profEl.value.trim() : '';
  const tmpClass = { id:'tmp-c-'+Date.now(), name, code, prof, color:state.pickedColor };
  state.classes.push(tmpClass);
  closeModal('class-modal');
  toast('🎓 Class added!');
  render();
  const res = await apiPost('add_class',{name,code,color:state.pickedColor,prof});
  if (res.ok && res.id) {
    const c = state.classes.find(x=>x.id===tmpClass.id);
    if (c) c.id = String(res.id);
  }
}

/* ═══════════════════════════════════════════
   SETTINGS — SAVE NAME
═══════════════════════════════════════════ */
async function saveName() {
  const name = document.getElementById('s-name').value.trim();
  if (!name) { toast('⚠️ Name cannot be empty'); return; }
  const res = await apiPost('update_name', { name });
  if (res.ok) {
    document.getElementById('display-name').textContent = name;
    // Update sidebar user bar
    document.querySelector('.user-name').textContent = name;
    toast('✅ Name updated!');
  } else {
    toast('❌ Failed to update name');
  }
}

/* ═══════════════════════════════════════════
   SETTINGS — SAVE EMAIL
═══════════════════════════════════════════ */
async function saveEmail() {
  const email = document.getElementById('s-email').value.trim();
  if (!email || !email.includes('@')) { toast('⚠️ Enter a valid email'); return; }
  const res = await apiPost('update_email', { email });
  if (res.ok) {
    document.getElementById('display-email').textContent = email;
    toast('✅ Email updated!');
  } else {
    toast('❌ Failed to update email');
  }
}

/* ═══════════════════════════════════════════
   SETTINGS — CHANGE PASSWORD
═══════════════════════════════════════════ */
async function savePassword() {
  const oldPw  = document.getElementById('s-pw-old').value;
  const newPw  = document.getElementById('s-pw-new').value;
  const confPw = document.getElementById('s-pw-confirm').value;
  if (!oldPw)           { toast('⚠️ Enter your current password'); return; }
  if (newPw.length < 8) { toast('⚠️ New password must be at least 8 characters'); return; }
  if (newPw !== confPw) { toast('⚠️ New passwords do not match'); return; }
  const res = await apiPost('change_password', { old_password: oldPw, new_password: newPw });
  if (res.ok) {
    document.getElementById('s-pw-old').value    = '';
    document.getElementById('s-pw-new').value    = '';
    document.getElementById('s-pw-confirm').value= '';
    document.getElementById('pw-fill').style.width = '0%';
    document.getElementById('pw-hint').textContent  = '';
    toast('✅ Password changed successfully!');
  } else {
    toast(res.error ? `❌ ${res.error}` : '❌ Incorrect current password');
  }
}

/* ── Password strength indicator ── */
function checkPwStrength(val) {
  const fill  = document.getElementById('pw-fill');
  const hint  = document.getElementById('pw-hint');
  let score = 0;
  if (val.length >= 8)            score++;
  if (val.length >= 12)           score++;
  if (/[A-Z]/.test(val))         score++;
  if (/[0-9]/.test(val))         score++;
  if (/[^A-Za-z0-9]/.test(val))  score++;
  const map = [
    {w:'0%',   bg:'transparent', txt:''},
    {w:'25%',  bg:'#D4607A',     txt:'Weak'},
    {w:'50%',  bg:'#E09B2D',     txt:'Fair'},
    {w:'75%',  bg:'#5B9BD5',     txt:'Good'},
    {w:'100%', bg:'#6A8F6E',     txt:'Strong'},
  ];
  const s = Math.min(score, 4);
  fill.style.width      = map[s].w;
  fill.style.background = map[s].bg;
  hint.textContent      = map[s].txt;
}

/* ── Toggle password visibility ── */
function togglePwField(id, btn) {
  const input = document.getElementById(id);
  const icon  = btn.querySelector('i');
  if (input.type === 'password') {
    input.type     = 'text';
    icon.className = 'ti ti-eye-off';
  } else {
    input.type     = 'password';
    icon.className = 'ti ti-eye';
  }
}

/* ═══════════════════════════════════════════
   SETTINGS — SAVE PREFERENCES
═══════════════════════════════════════════ */
function savePreferences() {
  // Store in localStorage for now (no DB column needed)
  const prefs = {
    defaultType:     document.getElementById('pref-type').value,
    defaultPriority: document.getElementById('pref-priority').value,
  };
  localStorage.setItem('studyflow_prefs', JSON.stringify(prefs));
  closeModal('settings-modal');
  toast('✅ Preferences saved!');
}

/* ═══════════════════════════════════════════
   MODAL HELPERS
═══════════════════════════════════════════ */
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

document.querySelectorAll('.overlay').forEach(el => {
  el.addEventListener('click', e => { if (e.target===el) el.classList.remove('open'); });
});
document.addEventListener('keydown', e => {
  if (e.key==='Escape')
    document.querySelectorAll('.overlay.open').forEach(m=>m.classList.remove('open'));
  if (e.key==='Enter'
      && document.getElementById('task-modal').classList.contains('open')
      && e.target.tagName!=='TEXTAREA')
    saveTask();
  if (e.key==='n' && !e.target.matches('input,textarea,select'))
    openTaskModal();
});

/* ═══════════════════════════════════════════
   MOBILE MENU
═══════════════════════════════════════════ */
function openMobileMenu() {
  document.getElementById('sidebar').classList.add('mob-open');
  document.getElementById('mob-backdrop').classList.add('active');
  document.body.style.overflow = 'hidden';
}
function closeMobileMenu() {
  document.getElementById('sidebar').classList.remove('mob-open');
  document.getElementById('mob-backdrop').classList.remove('active');
  document.body.style.overflow = '';
}

/* Mobile bottom nav active state */
function setMobNav(btn) {
  document.querySelectorAll('.mob-nav-item').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
}

/* ═══════════════════════════════════════════
   TOAST
═══════════════════════════════════════════ */
function toast(msg) {
  const container = document.getElementById('toast-container');
  const el        = document.createElement('div');
  el.className    = 'toast';
  el.innerHTML    = msg;
  container.appendChild(el);
  setTimeout(()=>el.remove(), 2700);
}

/* ═══════════════════════════════════════════
   DATE FOOTER
═══════════════════════════════════════════ */
function setDate() {
  const el = document.getElementById('footer-date');
  if (el) el.textContent = new Date().toLocaleDateString('en-MY',{
    weekday:'long', year:'numeric', month:'long', day:'numeric'
  });
}

/* ═══════════════════════════════════════════
   LOAD SAVED PREFERENCES
═══════════════════════════════════════════ */
function loadPreferences() {
  try {
    const prefs = JSON.parse(localStorage.getItem('studyflow_prefs') || '{}');
    if (prefs.defaultType)     document.getElementById('pref-type').value     = prefs.defaultType;
    if (prefs.defaultPriority) document.getElementById('pref-priority').value = prefs.defaultPriority;
  } catch {}
}

/* ═══════════════════════════════════════════
   BOOT
═══════════════════════════════════════════ */
setDate();
loadPreferences();
render();
// Request notification permission after a short delay (less intrusive)
setTimeout(requestNotificationPermission, 2000);