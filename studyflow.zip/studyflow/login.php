<?php
// ============================================================
//  login.php
// ============================================================
require_once 'config.php';
redirectIfLoggedIn();

$error = '';
$old   = ['email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password']      ?? '';
    $remember = isset($_POST['remember']);

    $old = ['email' => $email];

    // Basic presence check
    if ($email === '' || $password === '') {
        $error = 'Please enter your email and password.';
    } else {
        $pdo  = getDB();
        $stmt = $pdo->prepare('SELECT id, full_name, password FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // ── Successful login ───────────────────────────
            startSecureSession();
            session_regenerate_id(true);
            $_SESSION['user_id']   = (int) $user['id'];
            $_SESSION['user_name'] = $user['full_name'];

            // Optional "remember me" — extend cookie lifetime
            if ($remember) {
                $params = session_get_cookie_params();
                setcookie(session_name(), session_id(), [
                    'expires'  => time() + 60 * 60 * 24 * 30, // 30 days
                    'path'     => $params['path'],
                    'secure'   => $params['secure'],
                    'httponly' => $params['httponly'],
                    'samesite' => 'Strict',
                ]);
            }

            header('Location: index.php');
            exit;

        } else {
            // Generic error — don't reveal whether email exists
            $error = 'Incorrect email or password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — StudyFlow</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;500;600;700;800&family=Fraunces:opsz,wght@9..144,400;9..144,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.47.0/tabler-icons.min.css">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html { font-size: 15px; }

  body {
    font-family: 'Nunito', sans-serif;
    background: #FEF9F3;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
  }

  body::before {
    content: '';
    position: fixed; top: -80px; right: -80px;
    width: 360px; height: 360px; border-radius: 50%;
    background: radial-gradient(circle, #FFE4CC 0%, transparent 70%);
    pointer-events: none;
  }
  body::after {
    content: '';
    position: fixed; bottom: -60px; left: -60px;
    width: 300px; height: 300px; border-radius: 50%;
    background: radial-gradient(circle, #EBF5EC 0%, transparent 70%);
    pointer-events: none;
  }

  .card {
    background: #fff; border-radius: 20px;
    box-shadow: 0 16px 48px rgba(45,36,22,0.12);
    width: 100%; max-width: 420px; padding: 40px 36px;
    position: relative; z-index: 1;
    animation: cardIn .35s cubic-bezier(.34,1.56,.64,1);
  }
  @keyframes cardIn { from { opacity:0; transform:translateY(20px) scale(.97); } to { opacity:1; transform:none; } }

  .logo-row { text-align: center; margin-bottom: 28px; }
  .logo-emoji { font-size: 36px; display: block; margin-bottom: 8px; }
  .logo-name  {
    font-family: 'Fraunces', serif;
    font-size: 26px; font-weight: 600; color: #2D2416; letter-spacing: -0.4px;
  }
  .logo-sub { font-size: 13px; color: #9A8872; margin-top: 4px; }

  h1       { font-family: 'Fraunces', serif; font-size: 20px; font-weight: 600; color: #2D2416; margin-bottom: 6px; }
  .subtitle { font-size: 13px; color: #9A8872; margin-bottom: 24px; }

  .alert-error {
    background: #FDEEF2; border: 1.5px solid #F5B8C4; border-radius: 10px;
    padding: 12px 14px; margin-bottom: 18px;
    font-size: 13px; color: #9B2335;
    display: flex; align-items: center; gap: 8px;
    animation: shake .4s ease;
  }
  @keyframes shake {
    0%,100% { transform: translateX(0); }
    20%,60% { transform: translateX(-6px); }
    40%,80% { transform: translateX(6px); }
  }

  .alert-success {
    background: #ECFDF5; border: 1.5px solid #6EE7B7; border-radius: 10px;
    padding: 12px 14px; margin-bottom: 18px;
    font-size: 13px; color: #065F46;
    display: flex; align-items: center; gap: 8px;
  }

  .form-group { margin-bottom: 16px; }
  .form-label {
    display: block; font-size: 11.5px; font-weight: 800;
    color: #5C4D3A; letter-spacing: .05em;
    text-transform: uppercase; margin-bottom: 6px;
  }
  .input-wrap { position: relative; }
  .input-icon {
    position: absolute; left: 13px; top: 50%; transform: translateY(-50%);
    color: #9A8872; font-size: 17px; pointer-events: none;
  }
  .form-input {
    width: 100%; padding: 11px 13px 11px 40px;
    border: 1.5px solid rgba(45,36,22,.15);
    border-radius: 10px; font-family: 'Nunito', sans-serif;
    font-size: 14px; color: #2D2416; background: #FEF9F3;
    outline: none; transition: all .15s;
  }
  .form-input:focus {
    border-color: #D96B3F; background: #fff;
    box-shadow: 0 0 0 3px rgba(217,107,63,.12);
  }
  .toggle-pw {
    position: absolute; right: 13px; top: 50%; transform: translateY(-50%);
    background: none; border: none; cursor: pointer;
    color: #9A8872; font-size: 17px; padding: 0; transition: color .15s;
  }
  .toggle-pw:hover { color: #D96B3F; }

  .row-space {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 20px; font-size: 13px;
  }
  .checkbox-wrap { display: flex; align-items: center; gap: 8px; cursor: pointer; color: #5C4D3A; }
  .checkbox-wrap input[type="checkbox"] { accent-color: #D96B3F; width: 15px; height: 15px; }
  .forgot-link { color: #D96B3F; text-decoration: none; font-weight: 700; font-size: 12.5px; }
  .forgot-link:hover { text-decoration: underline; }

  .submit-btn {
    width: 100%; padding: 13px;
    background: #D96B3F; color: white; border: none;
    border-radius: 10px; font-family: 'Nunito', sans-serif;
    font-size: 15px; font-weight: 800; cursor: pointer;
    transition: all .18s;
    display: flex; align-items: center; justify-content: center; gap: 8px;
    box-shadow: 0 4px 14px rgba(217,107,63,.35);
  }
  .submit-btn:hover { background: #9E3D18; transform: translateY(-1px); box-shadow: 0 6px 18px rgba(217,107,63,.4); }
  .submit-btn:active { transform: none; }

  .divider { text-align: center; color: #9A8872; font-size: 12.5px; margin: 18px 0; position: relative; }
  .divider::before, .divider::after {
    content: ''; position: absolute; top: 50%;
    width: 38%; height: 1px; background: rgba(45,36,22,.1);
  }
  .divider::before { left: 0; }
  .divider::after  { right: 0; }

  .register-link { text-align: center; font-size: 13.5px; color: #5C4D3A; }
  .register-link a { color: #D96B3F; font-weight: 700; text-decoration: none; }
  .register-link a:hover { text-decoration: underline; }

  .demo-box {
    margin-top: 22px; padding: 12px 14px;
    background: #F5ECD8; border-radius: 10px;
    font-size: 12px; color: #5C4D3A; line-height: 1.6;
  }
  .demo-box strong { color: #D96B3F; }
</style>
</head>
<body>

<div class="card">

  <div class="logo-row">
    <span class="logo-emoji">📚</span>
    <div class="logo-name">StudyFlow</div>
    <div class="logo-sub">Your academic companion</div>
  </div>

  <h1>Welcome back! 👋</h1>
  <p class="subtitle">Sign in to manage your assignments and stay ahead.</p>

  <?php if ($error !== ''): ?>
  <div class="alert-error">
    <i class="ti ti-alert-circle"></i>
    <?= h($error) ?>
  </div>
  <?php endif; ?>

  <?php if (isset($_GET['registered'])): ?>
  <div class="alert-success">
    <i class="ti ti-circle-check"></i>
    Account created! You can now sign in.
  </div>
  <?php endif; ?>

  <form method="POST" action="login.php" novalidate>

    <!-- Email -->
    <div class="form-group">
      <label class="form-label" for="email">Email address</label>
      <div class="input-wrap">
        <i class="ti ti-mail input-icon"></i>
        <input class="form-input" type="email" id="email" name="email"
               value="<?= h($old['email']) ?>"
               placeholder="you@university.edu.my"
               autocomplete="email" required autofocus>
      </div>
    </div>

    <!-- Password -->
    <div class="form-group">
      <label class="form-label" for="password">Password</label>
      <div class="input-wrap">
        <i class="ti ti-lock input-icon"></i>
        <input class="form-input" type="password" id="password" name="password"
               placeholder="Your password"
               autocomplete="current-password" required>
        <button type="button" class="toggle-pw" onclick="togglePw()" tabindex="-1">
          <i class="ti ti-eye" id="eye-icon"></i>
        </button>
      </div>
    </div>

    <!-- Remember me + forgot -->
    <div class="row-space">
      <label class="checkbox-wrap">
        <input type="checkbox" name="remember">
        Remember me
      </label>
      <a class="forgot-link" href="forgot_password.php">Forgot password?</a>
    </div>

    <button type="submit" class="submit-btn">
      <i class="ti ti-login"></i> Sign in
    </button>
  </form>

  <div class="divider">or</div>
  <div class="register-link">New student? <a href="register.php">Create a free account</a></div>

  <div class="demo-box">
    💡 <strong>First time?</strong> Click "Create a free account" above — it only takes 30 seconds and you'll get starter classes already set up for you!
  </div>

</div>

<script>
function togglePw() {
  const input = document.getElementById('password');
  const icon  = document.getElementById('eye-icon');
  if (input.type === 'password') {
    input.type    = 'text';
    icon.className = 'ti ti-eye-off';
  } else {
    input.type    = 'password';
    icon.className = 'ti ti-eye';
  }
}
</script>
</body>
</html>
