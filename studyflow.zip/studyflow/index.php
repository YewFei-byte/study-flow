<?php
// ============================================================
//  index.php  —  Main app (requires login)
// ============================================================
require_once 'config.php';
requireLogin();

$userName  = htmlspecialchars($_SESSION['user_name'],  ENT_QUOTES, 'UTF-8');
$userEmail = htmlspecialchars($_SESSION['user_email'] ?? '', ENT_QUOTES, 'UTF-8');
$userId    = (int) $_SESSION['user_id'];

$pdo  = getDB();
$stmt = $pdo->prepare('SELECT * FROM classes WHERE user_id = ? ORDER BY name');
$stmt->execute([$userId]);
$classes = $stmt->fetchAll();

$stmt2 = $pdo->prepare(
    'SELECT t.*, c.name AS class_name, c.code AS class_code, c.color AS class_color
     FROM tasks t LEFT JOIN classes c ON t.class_id = c.id
     WHERE t.user_id = ? ORDER BY t.due_date ASC'
);
$stmt2->execute([$userId]);
$tasks = $stmt2->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>StudyFlow — Dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.47.0/tabler-icons.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- ══════════ MOBILE OVERLAY BACKDROP ══════════ -->
<div class="mob-backdrop" id="mob-backdrop" onclick="closeMobileMenu()"></div>

<div class="app-shell">

  <!-- ══════════ SIDEBAR (desktop + mobile drawer) ══════════ -->
  <aside class="sidebar" id="sidebar">

    <!-- Logo -->
    <div class="sidebar-header">
      <div class="logo-wrap">
        <span class="logo-emoji">📚</span>
        <div>
          <div class="logo-name">StudyFlow</div>
          <div class="logo-tagline">Your academic companion</div>
        </div>
      </div>
      <!-- Mobile close button -->
      <button class="mob-close-btn" onclick="closeMobileMenu()">
        <i class="ti ti-x"></i>
      </button>
    </div>

    <!-- Nav links -->
    <div class="sidebar-scroll">
      <div class="sidebar-section-label">Overview</div>
      <button class="nav-btn active" id="nav-all" onclick="setView('all',this);closeMobileMenu()">
        <i class="ti ti-layout-grid nav-icon"></i>
        <span class="nav-label">All Tasks</span>
        <span class="nav-count" id="cnt-all">0</span>
      </button>
      <button class="nav-btn" id="nav-today" onclick="setView('today',this);closeMobileMenu()">
        <i class="ti ti-calendar-event nav-icon"></i>
        <span class="nav-label">Due Today</span>
        <span class="nav-count" id="cnt-today">0</span>
      </button>
      <button class="nav-btn" id="nav-upcoming" onclick="setView('upcoming',this);closeMobileMenu()">
        <i class="ti ti-clock nav-icon"></i>
        <span class="nav-label">Upcoming (7 days)</span>
        <span class="nav-count" id="cnt-upcoming">0</span>
      </button>
      <button class="nav-btn" id="nav-overdue" onclick="setView('overdue',this);closeMobileMenu()">
        <i class="ti ti-alert-triangle nav-icon"></i>
        <span class="nav-label">Overdue</span>
        <span class="nav-count" id="cnt-overdue">0</span>
      </button>
      <button class="nav-btn" id="nav-done" onclick="setView('done',this);closeMobileMenu()">
        <i class="ti ti-circle-check nav-icon"></i>
        <span class="nav-label">Completed</span>
        <span class="nav-count" id="cnt-done">0</span>
      </button>

      <div class="sidebar-section-label" style="margin-top:16px;">My Classes</div>
      <div id="class-list"></div>
      <button class="add-class-btn" onclick="openClassModal()">
        <i class="ti ti-plus" style="font-size:15px"></i> Add new class
      </button>
    </div>

    <!-- User bar (no logout button here) -->
    <div class="user-bar" onclick="openModal('settings-modal')" title="Open settings" style="cursor:pointer">
      <div class="user-avatar"><?= mb_substr($userName, 0, 1) ?></div>
      <div class="user-info">
        <div class="user-name"><?= $userName ?></div>
        <div class="user-role">Student · tap to manage</div>
      </div>
      <i class="ti ti-chevron-right" style="color:var(--ink-muted);font-size:16px;flex-shrink:0"></i>
    </div>

    <!-- Date footer -->
    <div class="sidebar-footer">
      <i class="ti ti-calendar" style="font-size:13px"></i>
      <span id="footer-date"></span>
    </div>

  </aside>

  <!-- ══════════ MAIN ══════════ -->
  <main class="main">

    <!-- ── Desktop topbar ── -->
    <div class="topbar">
      <!-- Mobile hamburger -->
      <button class="mob-menu-btn" onclick="openMobileMenu()">
        <i class="ti ti-menu-2"></i>
      </button>
      <div class="topbar-left">
        <div class="topbar-title" id="topbar-title">All Tasks</div>
        <div class="topbar-sub" id="topbar-sub">Your complete coursework list</div>
      </div>
      <div class="topbar-actions">
        <!-- Quick Add removed — only New Assignment -->
        <button class="btn btn-primary" onclick="openTaskModal()">
          <i class="ti ti-pencil-plus"></i>
          <span class="btn-label">New Assignment</span>
        </button>
      </div>
    </div>

    <!-- Alert bar -->
    <div class="alert-bar" id="alert-bar" style="display:none">
      <div class="alert-pulse"></div>
      <i class="ti ti-bell" style="font-size:15px"></i>
      <span id="alert-text"></span>
      <button onclick="requestNotificationPermission()" id="notif-btn"
              style="margin-left:12px;font-size:11px;background:rgba(255,255,255,0.25);border:none;
                     border-radius:6px;padding:3px 10px;cursor:pointer;color:inherit;font-weight:700;
                     display:none">
        🔔 Enable alerts
      </button>
      <span style="margin-left:auto;font-size:11px;opacity:0.6;cursor:pointer"
            onclick="document.getElementById('alert-bar').style.display='none'">dismiss</span>
    </div>

    <!-- Content -->
    <div class="content-area">

      <!-- Stat cards -->
      <div class="stats-grid">
        <div class="stat-card total">
          <i class="ti ti-list-check stat-icon"></i>
          <div class="stat-num" id="s-total">0</div>
          <div class="stat-label">Active tasks</div>
        </div>
        <div class="stat-card overdue">
          <i class="ti ti-clock-exclamation stat-icon"></i>
          <div class="stat-num" id="s-overdue">0</div>
          <div class="stat-label">Overdue</div>
        </div>
        <div class="stat-card soon">
          <i class="ti ti-calendar-week stat-icon"></i>
          <div class="stat-num" id="s-soon">0</div>
          <div class="stat-label">Due this week</div>
        </div>
        <div class="stat-card done">
          <i class="ti ti-trophy stat-icon"></i>
          <div class="stat-num" id="s-done">0</div>
          <div class="stat-label">Completed 🎉</div>
        </div>
      </div>

      <!-- Progress -->
      <div class="progress-wrap">
        <div class="progress-left">
          <div class="progress-label">
            <span>Overall completion progress</span>
            <span id="progress-fraction">0 / 0 done</span>
          </div>
          <div class="progress-bar-bg">
            <div class="progress-bar-fill" id="progress-fill" style="width:0%"></div>
          </div>
        </div>
        <div class="progress-pct" id="progress-pct">0%</div>
      </div>

      <!-- Filter bar -->
      <div class="filter-bar">
        <button class="filter-chip active" onclick="setType('all',this)">All types</button>
        <button class="filter-chip" onclick="setType('assignment',this)">
          <i class="ti ti-file-text" style="font-size:13px"></i> Assignment
        </button>
        <button class="filter-chip" onclick="setType('quiz',this)">
          <i class="ti ti-pencil" style="font-size:13px"></i> Quiz
        </button>
        <button class="filter-chip" onclick="setType('project',this)">
          <i class="ti ti-layout-board" style="font-size:13px"></i> Project
        </button>
        <button class="filter-chip" onclick="setType('exam',this)">
          <i class="ti ti-school" style="font-size:13px"></i> Exam
        </button>
        <div class="filter-sep"></div>
        <div class="sort-wrap">
          <i class="ti ti-arrows-sort" style="font-size:14px"></i>
          <select class="sort-select" onchange="state.sortBy=this.value;renderTasks()">
            <option value="due">Due date</option>
            <option value="priority">Priority</option>
            <option value="subject">Subject</option>
            <option value="added">Date added</option>
          </select>
        </div>
      </div>

      <!-- Task list -->
      <div id="tasks-root"></div>
    </div>

    <!-- ── Mobile bottom navigation bar ── -->
    <nav class="mob-bottom-nav">
      <button class="mob-nav-item active" id="mob-nav-all" onclick="setView('all',document.getElementById('nav-all'));setMobNav(this)">
        <i class="ti ti-layout-grid"></i>
        <span>All</span>
      </button>
      <button class="mob-nav-item" id="mob-nav-today" onclick="setView('today',document.getElementById('nav-today'));setMobNav(this)">
        <i class="ti ti-calendar-event"></i>
        <span>Today</span>
      </button>
      <button class="mob-nav-item mob-nav-add" onclick="openTaskModal()">
        <i class="ti ti-plus"></i>
        <span>Add</span>
      </button>
      <button class="mob-nav-item" id="mob-nav-overdue" onclick="setView('overdue',document.getElementById('nav-overdue'));setMobNav(this)">
        <i class="ti ti-alert-triangle"></i>
        <span>Overdue</span>
      </button>
      <button class="mob-nav-item" onclick="openModal('settings-modal')">
        <i class="ti ti-settings"></i>
        <span>Settings</span>
      </button>
    </nav>

  </main>
</div>

<!-- ══════════ ADD TASK MODAL ══════════ -->
<div class="overlay" id="task-modal">
  <div class="modal">
    <div class="modal-header">
      <div>
        <div class="modal-title">New Assignment ✏️</div>
        <div class="modal-sub">Fill in the details below</div>
      </div>
      <button class="modal-close" onclick="closeModal('task-modal')"><i class="ti ti-x"></i></button>
    </div>
    <div class="form-group">
      <label class="form-label">What's the task? *</label>
      <input class="form-input" id="f-title" type="text" placeholder="e.g. Write chapter 3 summary…" autocomplete="off">
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Subject / Class</label>
        <select class="form-select" id="f-subject"></select>
      </div>
      <div class="form-group">
        <label class="form-label">Task type</label>
        <select class="form-select" id="f-type">
          <option value="assignment">📝 Assignment</option>
          <option value="quiz">🧠 Quiz</option>
          <option value="project">🛠 Project</option>
          <option value="exam">📖 Exam</option>
          <option value="reading">📚 Reading</option>
          <option value="lab">🔬 Lab Report</option>
          <option value="presentation">🎤 Presentation</option>
          <option value="other">📌 Other</option>
        </select>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Due date *</label>
        <input class="form-input" id="f-date" type="date">
        <div class="form-hint">When is this due?</div>
      </div>
      <div class="form-group">
        <label class="form-label">Priority</label>
        <select class="form-select" id="f-priority">
          <option value="medium">🟡 Medium</option>
          <option value="high">🔴 High</option>
          <option value="low">🟢 Low</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Notes / Details</label>
      <textarea class="form-textarea" id="f-notes" placeholder="Chapter numbers, submission link, special instructions…"></textarea>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('task-modal')">Cancel</button>
      <button class="btn btn-primary" onclick="saveTask()"><i class="ti ti-device-floppy"></i> Save task</button>
    </div>
  </div>
</div>

<!-- ══════════ EDIT TASK MODAL ══════════ -->
<div class="overlay" id="edit-modal">
  <div class="modal">
    <div class="modal-header">
      <div>
        <div class="modal-title">Edit Assignment ✏️</div>
        <div class="modal-sub">Update the task details below</div>
      </div>
      <button class="modal-close" onclick="closeModal('edit-modal')"><i class="ti ti-x"></i></button>
    </div>
    <div class="form-group">
      <label class="form-label">What's the task? *</label>
      <input class="form-input" id="e-title" type="text" placeholder="e.g. Write chapter 3 summary…" autocomplete="off">
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Subject / Class</label>
        <select class="form-select" id="e-subject"></select>
      </div>
      <div class="form-group">
        <label class="form-label">Task type</label>
        <select class="form-select" id="e-type">
          <option value="assignment">📝 Assignment</option>
          <option value="quiz">🧠 Quiz</option>
          <option value="project">🛠 Project</option>
          <option value="exam">📖 Exam</option>
          <option value="reading">📚 Reading</option>
          <option value="lab">🔬 Lab Report</option>
          <option value="presentation">🎤 Presentation</option>
          <option value="other">📌 Other</option>
        </select>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Due date *</label>
        <input class="form-input" id="e-date" type="date">
      </div>
      <div class="form-group">
        <label class="form-label">Priority</label>
        <select class="form-select" id="e-priority">
          <option value="medium">🟡 Medium</option>
          <option value="high">🔴 High</option>
          <option value="low">🟢 Low</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Notes / Details</label>
      <textarea class="form-textarea" id="e-notes" placeholder="Chapter numbers, submission link, special instructions…"></textarea>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('edit-modal')">Cancel</button>
      <button class="btn btn-primary" onclick="saveEdit()"><i class="ti ti-device-floppy"></i> Save changes</button>
    </div>
  </div>
</div>

<!-- ══════════ ADD CLASS MODAL ══════════ -->
<div class="overlay" id="class-modal">
  <div class="modal">
    <div class="modal-header">
      <div>
        <div class="modal-title">Add a Class 🎓</div>
        <div class="modal-sub">Organise your assignments by subject</div>
      </div>
      <button class="modal-close" onclick="closeModal('class-modal')"><i class="ti ti-x"></i></button>
    </div>
    <div class="form-group">
      <label class="form-label">Class name *</label>
      <input class="form-input" id="c-name" type="text" placeholder="e.g. Introduction to Psychology">
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Short code</label>
        <input class="form-input" id="c-code" type="text" placeholder="e.g. PSY101" maxlength="8">
      </div>
      <div class="form-group">
        <label class="form-label">Instructor (optional)</label>
        <input class="form-input" id="c-prof" type="text" placeholder="e.g. Dr. Smith">
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Class colour</label>
      <div class="color-row" id="color-row"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('class-modal')">Cancel</button>
      <button class="btn btn-primary" onclick="saveClass()"><i class="ti ti-plus"></i> Add class</button>
    </div>
  </div>
</div>

<!-- ══════════ SETTINGS MODAL ══════════ -->
<div class="overlay" id="settings-modal">
  <div class="modal settings-modal-wide">
    <div class="modal-header">
      <div>
        <div class="modal-title">⚙️ Settings</div>
        <div class="modal-sub">Manage your account and preferences</div>
      </div>
      <button class="modal-close" onclick="closeModal('settings-modal')"><i class="ti ti-x"></i></button>
    </div>

    <!-- ── Profile card ── -->
    <div class="settings-section">
      <div class="settings-section-title">Account</div>
      <div class="settings-info-row">
        <div class="settings-avatar"><?= mb_substr($userName, 0, 1) ?></div>
        <div class="settings-user-detail">
          <div class="settings-user-name" id="display-name"><?= $userName ?></div>
          <div class="settings-user-email" id="display-email"><?= $userEmail ?: 'No email on record' ?></div>
        </div>
        <div class="settings-badge">Student</div>
      </div>
    </div>

    <!-- ── Edit name ── -->
    <div class="settings-section">
      <div class="settings-section-title">Personal Information</div>
      <div class="form-group">
        <label class="form-label">Full name</label>
        <div style="display:flex;gap:8px">
          <input class="form-input" id="s-name" type="text"
                 value="<?= $userName ?>" placeholder="Your full name" style="flex:1">
          <button class="btn btn-ghost" onclick="saveName()" style="flex-shrink:0;white-space:nowrap">
            <i class="ti ti-check"></i> Save
          </button>
        </div>
        <div class="form-hint">This is shown in the sidebar and settings.</div>
      </div>

      <div class="form-group">
        <label class="form-label">Email (Gmail)</label>
        <div style="display:flex;gap:8px">
          <div style="position:relative;flex:1">
            <i class="ti ti-mail" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--ink-muted);font-size:16px"></i>
            <input class="form-input" id="s-email" type="email"
                   value="<?= $userEmail ?>"
                   placeholder="you@gmail.com"
                   style="padding-left:38px">
          </div>
          <button class="btn btn-ghost" onclick="saveEmail()" style="flex-shrink:0;white-space:nowrap">
            <i class="ti ti-check"></i> Save
          </button>
        </div>
        <div class="form-hint">Used for account identification only.</div>
      </div>
    </div>

    <!-- ── Change password ── -->
    <div class="settings-section">
      <div class="settings-section-title">Change Password</div>
      <div class="form-group">
        <label class="form-label">Current password</label>
        <div style="position:relative">
          <i class="ti ti-lock" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--ink-muted);font-size:16px"></i>
          <input class="form-input" id="s-pw-old" type="password" placeholder="Enter current password" style="padding-left:38px">
          <button type="button" class="pw-toggle" onclick="togglePwField('s-pw-old',this)">
            <i class="ti ti-eye"></i>
          </button>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">New password</label>
          <div style="position:relative">
            <i class="ti ti-lock-plus" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--ink-muted);font-size:16px"></i>
            <input class="form-input" id="s-pw-new" type="password" placeholder="Min. 8 characters" style="padding-left:38px" oninput="checkPwStrength(this.value)">
            <button type="button" class="pw-toggle" onclick="togglePwField('s-pw-new',this)">
              <i class="ti ti-eye"></i>
            </button>
          </div>
          <div class="pw-strength-bar"><div class="pw-strength-fill" id="pw-fill"></div></div>
          <div class="form-hint" id="pw-hint"></div>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm new password</label>
          <div style="position:relative">
            <i class="ti ti-lock-check" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--ink-muted);font-size:16px"></i>
            <input class="form-input" id="s-pw-confirm" type="password" placeholder="Re-enter new password" style="padding-left:38px">
            <button type="button" class="pw-toggle" onclick="togglePwField('s-pw-confirm',this)">
              <i class="ti ti-eye"></i>
            </button>
          </div>
        </div>
      </div>
      <button class="btn btn-ghost" onclick="savePassword()" style="margin-top:4px">
        <i class="ti ti-key"></i> Update password
      </button>
    </div>

    <!-- ── Preferences ── -->
    <div class="settings-section">
      <div class="settings-section-title">Preferences</div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Default task type</label>
          <select class="form-select" id="pref-type">
            <option value="assignment">📝 Assignment</option>
            <option value="quiz">🧠 Quiz</option>
            <option value="project">🛠 Project</option>
            <option value="exam">📖 Exam</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Default priority</label>
          <select class="form-select" id="pref-priority">
            <option value="medium">🟡 Medium</option>
            <option value="high">🔴 High</option>
            <option value="low">🟢 Low</option>
          </select>
        </div>
      </div>
    </div>

    <!-- ── Sign out ── -->
    <div class="settings-section">
      <div class="settings-section-title" style="color:var(--rose)">Account Actions</div>
      <a href="logout.php" class="sign-out-btn">
        <i class="ti ti-logout"></i> Sign out
      </a>
    </div>

    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('settings-modal')">Close</button>
      <button class="btn btn-primary" onclick="savePreferences()">
        <i class="ti ti-check"></i> Save preferences
      </button>
    </div>
  </div>
</div>

<!-- ══════════ CONFIRM DELETE CLASS ══════════ -->
<div class="overlay" id="confirm-modal">
  <div class="modal" style="max-width:380px">
    <div class="modal-header">
      <div>
        <div class="modal-title" style="color:var(--rose)">🗑️ Delete Class</div>
        <div class="modal-sub">This cannot be undone</div>
      </div>
      <button class="modal-close" onclick="closeModal('confirm-modal')"><i class="ti ti-x"></i></button>
    </div>
    <p style="font-family:'Times New Roman',Times,serif;font-size:14px;color:var(--ink-soft);line-height:1.6">
      Are you sure you want to delete <strong id="confirm-class-name"></strong>?
      All tasks linked to this class will also be removed.
    </p>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('confirm-modal')">Cancel</button>
      <button class="btn" style="background:var(--rose);color:white" onclick="confirmDeleteClass()">
        <i class="ti ti-trash"></i> Yes, delete
      </button>
    </div>
  </div>
</div>

<div class="toast-container" id="toast-container"></div>

<!-- PHP → JS -->
<script>
const DB_CLASSES = <?= json_encode(array_map(fn($c) => [
  'id'    => (string)$c['id'],
  'name'  => $c['name'],
  'code'  => $c['code'],
  'color' => $c['color'],
  'prof'  => $c['prof'] ?? '',
], $classes)) ?>;

const DB_TASKS = <?= json_encode(array_map(fn($t) => [
  'id'        => (string)$t['id'],
  'title'     => $t['title'],
  'subject'   => (string)$t['class_id'],
  'type'      => $t['type'],
  'due'       => $t['due_date'],
  'priority'  => $t['priority'],
  'notes'     => $t['notes'] ?? '',
  'done'      => (bool)$t['is_done'],
  'createdAt' => strtotime($t['created_at']) * 1000,
], $tasks)) ?>;

const CURRENT_USER = <?= json_encode(['id'=>$userId,'name'=>$userName,'email'=>$userEmail]) ?>;
</script>
<script src="js/app.js"></script>
</body>
</html>