<?php
// ============================================================
//  api.php  —  JSON API for task & class CRUD
//  Called via fetch() from app.js
// ============================================================
require_once 'config.php';
requireLogin();

header('Content-Type: application/json');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

// Decode JSON body
$body = json_decode(file_get_contents('php://input'), true);
if (!$body || !isset($body['action'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Bad request']);
    exit;
}

$userId = (int) $_SESSION['user_id'];
$pdo    = getDB();
$action = $body['action'];

try {
    switch ($action) {

        // ── Add a new task ─────────────────────────────────
        case 'add_task': {
            $classId  = isset($body['class_id']) && $body['class_id'] !== '' ? (int)$body['class_id'] : null;
            $title    = trim($body['title']    ?? '');
            $type     = $body['type']           ?? 'assignment';
            $dueDate  = $body['due_date']       ?? '';
            $priority = $body['priority']       ?? 'medium';
            $notes    = trim($body['notes']     ?? '');

            if ($title === '' || $dueDate === '') {
                echo json_encode(['ok' => false, 'error' => 'Missing required fields']);
                break;
            }

            // Verify the class belongs to this user (if provided)
            if ($classId !== null) {
                $chk = $pdo->prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?');
                $chk->execute([$classId, $userId]);
                if (!$chk->fetch()) $classId = null;
            }

            $stmt = $pdo->prepare(
                'INSERT INTO tasks (user_id, class_id, title, type, due_date, priority, notes)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([$userId, $classId, $title, $type, $dueDate, $priority, $notes]);
            echo json_encode(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
            break;
        }

        // ── Toggle task done/undone ────────────────────────
        case 'toggle_task': {
            $id     = (int)($body['id'] ?? 0);
            $isDone = (int)(bool)($body['is_done'] ?? 0);

            $stmt = $pdo->prepare(
                'UPDATE tasks SET is_done = ? WHERE id = ? AND user_id = ?'
            );
            $stmt->execute([$isDone, $id, $userId]);
            echo json_encode(['ok' => true]);
            break;
        }

        // ── Edit an existing task ──────────────────────────
        case 'edit_task': {
            $id       = (int)($body['id'] ?? 0);
            $classId  = isset($body['class_id']) && $body['class_id'] !== '' ? (int)$body['class_id'] : null;
            $title    = trim($body['title']    ?? '');
            $type     = $body['type']           ?? 'assignment';
            $dueDate  = $body['due_date']       ?? '';
            $priority = $body['priority']       ?? 'medium';
            $notes    = trim($body['notes']     ?? '');

            if ($title === '' || $dueDate === '') {
                echo json_encode(['ok' => false, 'error' => 'Missing required fields']);
                break;
            }
            if ($classId !== null) {
                $chk = $pdo->prepare('SELECT id FROM classes WHERE id = ? AND user_id = ?');
                $chk->execute([$classId, $userId]);
                if (!$chk->fetch()) $classId = null;
            }
            $stmt = $pdo->prepare(
                'UPDATE tasks SET class_id=?, title=?, type=?, due_date=?, priority=?, notes=?
                 WHERE id=? AND user_id=?'
            );
            $stmt->execute([$classId, $title, $type, $dueDate, $priority, $notes, $id, $userId]);
            echo json_encode(['ok' => true]);
            break;
        }

        // ── Delete a task ──────────────────────────────────
        case 'delete_task': {
            $id   = (int)($body['id'] ?? 0);
            $stmt = $pdo->prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?');
            $stmt->execute([$id, $userId]);
            echo json_encode(['ok' => true]);
            break;
        }

        // ── Add a class ────────────────────────────────────
        case 'add_class': {
            $name  = trim($body['name']  ?? '');
            $code  = trim($body['code']  ?? '');
            $color = $body['color']       ?? '#5B9BD5';
            $prof  = trim($body['prof']  ?? '');

            if ($name === '') {
                echo json_encode(['ok' => false, 'error' => 'Name required']);
                break;
            }
            if ($code === '') $code = strtoupper(substr($name, 0, 6));

            $stmt = $pdo->prepare(
                'INSERT INTO classes (user_id, name, code, color, prof) VALUES (?, ?, ?, ?, ?)'
            );
            $stmt->execute([$userId, $name, $code, $color, $prof]);
            echo json_encode(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
            break;
        }

        // ── Delete a class ─────────────────────────────────
        case 'delete_class': {
            $id   = (int)($body['id'] ?? 0);
            $stmt = $pdo->prepare('DELETE FROM classes WHERE id = ? AND user_id = ?');
            $stmt->execute([$id, $userId]);
            echo json_encode(['ok' => true]);
            break;
        }

        default:
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => 'Unknown action']);
    }

} catch (PDOException $e) {
    error_log('api.php error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Server error']);
}
