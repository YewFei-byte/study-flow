<?php
// ============================================================
//  logout.php
//  Destroys the session and redirects to the login page.
// ============================================================
require_once 'config.php';
startSecureSession();

// Wipe all session data
$_SESSION = [];

// Delete the session cookie
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires'  => time() - 42000,
        'path'     => $p['path'],
        'domain'   => $p['domain'],
        'secure'   => $p['secure'],
        'httponly'  => $p['httponly'],
        'samesite' => 'Strict',
    ]);
}

session_destroy();

header('Location: login.php?logged_out=1');
exit;
