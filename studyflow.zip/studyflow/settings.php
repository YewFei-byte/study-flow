<?php
// ============================================================
//  settings.php  —  User settings (profile, security,
//                   notifications, appearance, quiz history)
// ============================================================
require_once 'config.php';
requireLogin();

$userId = (int) $_SESSION['user_id'];
$pdo    = getDB();

// ── Load current user row ──────────────────────────────────
$stmt = $pdo->prepare('SELECT id, full_name, email FROM users WHERE id = ?');
$stmt->execute([$userId]);
$user = $stmt->fetch();

// ── Load preferences (gracefully if table absent) ─────────
$prefs = [
    'notif_quiz_results'  => 1,
    'notif_new_quizzes'   => 1,
    'notif_surveys'       => 0,
    'theme'               => 'light',
    'font_size'           => 15,
    'show_timer'          => 1,
];
try {
    $ps = $pdo->prepare('SELECT pref_key, pref_value FROM user_preferences WHERE user_id = ?');
    $ps->execute([$userId]);
    foreach ($ps->fetchAll() as $row) {
        $prefs[$row['pref_key']] = $row['pref_value'];
    }
} catch (PDOException $e) { /* table may not exist yet */ }

// ── Load quiz-history stats ────────────────────────────────
$totalTasks = 0; $doneTasks = 0; $highPriDone = 0;
try {
    $qs = $pdo->prepare('SELECT COUNT(*) AS cnt, SUM(is_done) AS done_cnt FROM tasks WHERE user_id = ?');
    $qs->execute([$userId]);
    $row = $qs->fetch();
    $totalTasks = (int)$row['cnt'];
    $doneTasks  = (int)$row['done_cnt'];

    $hs = $pdo->prepare("SELECT COUNT(*) AS cnt FROM tasks WHERE user_id = ? AND is_done = 1 AND priority = 'high'");
    $hs->execute([$userId]);
    $highPriDone = (int)$hs->fetch()['cnt'];
} catch (PDOException $e) {}

$completionRate = $totalTasks > 0 ? round(($doneTasks / $totalTasks) * 100) : 0;

// ── Flash messages ─────────────────────────────────────────
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// ── Handle POST actions ────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // — Save profile ——————————————————————————————————————
    if ($action === 'save_profile') {
        $fullName = trim($_POST['full_name'] ?? '');
        $email    = trim($_POST['email']     ?? '');
        $errors   = [];

        if ($fullName === '' || strlen($fullName) > 100) $errors[] = 'Name is required (max 100 chars).';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL))  $errors[] = 'Please enter a valid email address.';

        if (empty($errors)) {
            // Check email not taken by another user
            $chk = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
            $chk->execute([$email, $userId]);
            if ($chk->fetch()) {
                $errors[] = 'That email is already in use by another account.';
            }
        }

        if (empty($errors)) {
            $pdo->prepare('UPDATE users SET full_name = ?, email = ? WHERE id = ?')
                ->execute([$fullName, $email, $userId]);
            $_SESSION['user_name'] = $fullName;
            $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Profile updated successfully.', 'tab' => 'profile'];
        } else {
            $_SESSION['flash'] = ['type' => 'error', 'msg' => implode(' ', $errors), 'tab' => 'profile'];
        }
        header('Location: settings.php#profile'); exit;
    }

    // — Change password ————————————————————————————————————
    if ($action === 'change_password') {
        $current  = $_POST['current_password'] ?? '';
        $new      = $_POST['new_password']      ?? '';
        $confirm  = $_POST['confirm_password']  ?? '';
        $errors   = [];

        $dbRow = $pdo->prepare('SELECT password FROM users WHERE id = ?');
        $dbRow->execute([$userId]);
        $hash = $dbRow->fetchColumn();

        if (!password_verify($current, $hash)) $errors[] = 'Current password is incorrect.';
        if (strlen($new) < 8)                   $errors[] = 'New password must be at least 8 characters.';
        if ($new !== $confirm)                  $errors[] = 'New passwords do not match.';

        if (empty($errors)) {
            $newHash = password_hash($new, PASSWORD_BCRYPT, ['cost' => 12]);
            $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([$newHash, $userId]);
            $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Password changed successfully.', 'tab' => 'security'];
        } else {
            $_SESSION['flash'] = ['type' => 'error', 'msg' => implode(' ', $errors), 'tab' => 'security'];
        }
        header('Location: settings.php#security'); exit;
    }

    // — Sign out all devices ———————————————————————————————
    if ($action === 'signout_all') {
        // Regenerate session ID (invalidates old session cookie)
        session_regenerate_id(true);
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'All other devices have been signed out.', 'tab' => 'security'];
        header('Location: settings.php#security'); exit;
    }

    // — Save notifications ————————————————————————————————
    if ($action === 'save_notifications') {
        $keys = ['notif_quiz_results', 'notif_new_quizzes', 'notif_surveys'];
        foreach ($keys as $key) {
            $val = isset($_POST[$key]) ? 1 : 0;
            savePref($pdo, $userId, $key, $val);
        }
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Notification preferences saved.', 'tab' => 'notifications'];
        header('Location: settings.php#notifications'); exit;
    }

    // — Save appearance ————————————————————————————————————
    if ($action === 'save_appearance') {
        $theme     = in_array($_POST['theme'] ?? '', ['light','dark','system']) ? $_POST['theme'] : 'light';
        $fontSize  = max(12, min(20, (int)($_POST['font_size'] ?? 15)));
        $showTimer = isset($_POST['show_timer']) ? 1 : 0;
        savePref($pdo, $userId, 'theme',      $theme);
        savePref($pdo, $userId, 'font_size',  $fontSize);
        savePref($pdo, $userId, 'show_timer', $showTimer);
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Appearance settings saved.', 'tab' => 'appearance'];
        header('Location: settings.php#appearance'); exit;
    }

    // — Clear quiz history ————————————————————————————————
    if ($action === 'clear_history') {
        $pdo->prepare('DELETE FROM tasks WHERE user_id = ?')->execute([$userId]);
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'All task history has been cleared.', 'tab' => 'history'];
        header('Location: settings.php#history'); exit;
    }
}

// ── Helper: upsert a user preference ──────────────────────
function savePref(PDO $pdo, int $userId, string $key, $value): void {
    $pdo->prepare(
        'INSERT INTO user_preferences (user_id, pref_key, pref_value)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE pref_value = VALUES(pref_value)'
    )->execute([$userId, $key, $value]);
}

// ── Derive initials & display name ────────────────────────
$displayName = h($user['full_name']);
$nameParts   = explode(' ', trim($user['full_name']));
$initials    = mb_strtoupper(mb_substr($nameParts[0], 0, 1) . mb_substr(end($nameParts), 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>StudyFlow — Settings</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&family=Fraunces:opsz,wght@9..144,300;9..144,400;9..144,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.47.0/tabler-icons.min.css">
<link rel="stylesheet" href="css/style.css">
<style>
/* ── Settings-page layout ─────────────────────────────── */
.settings-shell {
  display: flex;
  height: 100vh;
  overflow: hidden;
}

/* ── Settings sidebar ─────────────────────────────────── */
.settings-sidebar {
  width: 260px;
  flex-shrink: 0;
  background: var(--white);
  border-right: 1.5px solid var(--border);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.settings-sidebar .sidebar-header {
  padding: 28px 24px 20px;
  background: linear-gradient(160deg, #D96B3F 0%, #E09B2D 100%);
  position: relative;
  overflow: hidden;
}
.settings-sidebar .sidebar-header::before {
  content:''; position:absolute; top:-30px; right:-30px;
  width:100px; height:100px; background:rgba(255,255,255,0.12); border-radius:50%;
}
.settings-sidebar .sidebar-header::after {
  content:''; position:absolute; bottom:-20px; left:-10px;
  width:70px; height:70px; background:rgba(255,255,255,0.08); border-radius:50%;
}
.settings-nav { flex: 1; padding: 12px 12px; overflow-y: auto; }
.settings-nav-item {
  display: flex; align-items: center; gap: 11px;
  padding: 10px 13px; border-radius: var(--radius-sm);
  font-size: 13.5px; font-weight: 500; color: var(--ink-soft);
  cursor: pointer; border: none; background: none;
  width: 100%; text-align: left; font-family: 'Nunito', sans-serif;
  transition: all 0.16s;
  text-decoration: none;
}
.settings-nav-item:hover { background: var(--cream-dark); color: var(--ink); }
.settings-nav-item.active {
  background: var(--peach); color: var(--terra-dark);
  font-weight: 700; border-left: 3px solid var(--terracotta);
}
.settings-nav-item i { font-size: 18px; flex-shrink: 0; }
.settings-nav-divider {
  height: 1px; background: var(--border); margin: 8px 0;
}

/* ── Settings main panel ──────────────────────────────── */
.settings-main {
  flex: 1; overflow-y: auto; background: var(--cream);
}
.settings-topbar {
  background: var(--white);
  border-bottom: 1.5px solid var(--border);
  padding: 16px 32px;
  display: flex; align-items: center; gap: 14px;
}
.settings-topbar .back-btn {
  display: inline-flex; align-items: center; gap: 6px;
  font-size: 13px; font-weight: 600; color: var(--ink-muted);
  text-decoration: none; padding: 7px 12px;
  border-radius: var(--radius-xs); transition: all 0.15s;
  border: 1.5px solid var(--border);
  background: var(--white);
  font-family: 'Nunito', sans-serif;
}
.settings-topbar .back-btn:hover {
  color: var(--terracotta); border-color: var(--terra-light);
  background: var(--peach);
}
.settings-topbar-title {
  font-family: 'Fraunces', serif;
  font-size: 22px; font-weight: 600; color: var(--ink);
  letter-spacing: -0.3px;
}

/* ── Tab sections ─────────────────────────────────────── */
.settings-body { padding: 28px 32px; }
.settings-tab { display: none; }
.settings-tab.active { display: block; }

.tab-heading {
  font-family: 'Fraunces', serif;
  font-size: 20px; font-weight: 600; color: var(--ink);
  margin-bottom: 4px;
}
.tab-sub {
  font-size: 13px; color: var(--ink-muted); margin-bottom: 24px;
}

/* ── Cards ────────────────────────────────────────────── */
.s-card {
  background: var(--white);
  border: 1.5px solid var(--border);
  border-radius: var(--radius);
  padding: 24px 26px;
  margin-bottom: 18px;
}
.s-card-label {
  font-size: 10px; font-weight: 800; color: var(--ink-muted);
  letter-spacing: 0.1em; text-transform: uppercase;
  margin-bottom: 16px;
}

/* ── Profile user row ─────────────────────────────────── */
.profile-row {
  display: flex; align-items: center; gap: 16px;
  padding-bottom: 20px; margin-bottom: 20px;
  border-bottom: 1.5px solid var(--border);
}
.profile-avatar {
  width: 54px; height: 54px; border-radius: 50%;
  background: var(--peach);
  display: flex; align-items: center; justify-content: center;
  font-size: 17px; font-weight: 800; color: var(--terra-dark);
  flex-shrink: 0; border: 2px solid var(--terracotta);
}
.profile-name  { font-size: 15px; font-weight: 700; color: var(--ink); }
.profile-meta  { font-size: 12px; color: var(--ink-muted); margin-top: 2px; display: flex; align-items: center; gap: 6px; }
.role-badge {
  background: var(--amber-bg); color: var(--amber);
  font-size: 11px; font-weight: 700; padding: 2px 9px;
  border-radius: 99px;
}

/* ── Form fields ──────────────────────────────────────── */
.s-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.s-field { margin-bottom: 14px; }
.s-field label {
  display: block; font-size: 12.5px; font-weight: 700;
  color: var(--ink-soft); margin-bottom: 6px;
}
.s-field input {
  width: 100%; height: 40px;
  border: 1.5px solid var(--border-med);
  border-radius: var(--radius-sm);
  padding: 0 13px;
  font-family: 'Nunito', sans-serif;
  font-size: 14px; color: var(--ink);
  background: var(--cream);
  outline: none; transition: border-color 0.15s, box-shadow 0.15s;
}
.s-field input:focus {
  border-color: var(--terracotta);
  box-shadow: 0 0 0 3px rgba(217,107,63,0.12);
  background: var(--white);
}
.s-field input::placeholder { color: var(--ink-muted); }

/* ── Buttons ──────────────────────────────────────────── */
.s-btn-row { display: flex; justify-content: flex-end; margin-top: 6px; }
.s-btn {
  display: inline-flex; align-items: center; gap: 7px;
  padding: 9px 20px; border-radius: var(--radius-sm);
  font-family: 'Nunito', sans-serif;
  font-size: 13.5px; font-weight: 700; cursor: pointer;
  border: 1.5px solid var(--border); background: var(--cream-dark);
  color: var(--ink-soft); transition: all 0.16s;
}
.s-btn:hover { background: var(--peach); color: var(--terracotta); border-color: var(--terra-light); }
.s-btn-primary {
  background: var(--terracotta); color: white;
  border-color: var(--terracotta);
  box-shadow: 0 3px 12px rgba(217,107,63,0.3);
}
.s-btn-primary:hover { background: var(--terra-dark); border-color: var(--terra-dark); }
.s-btn-danger {
  background: var(--rose-bg); color: var(--rose);
  border-color: rgba(212,96,122,0.3);
}
.s-btn-danger:hover { background: var(--rose); color: white; border-color: var(--rose); }

/* ── Toggle switches ──────────────────────────────────── */
.notif-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 0; border-bottom: 1.5px solid var(--border);
}
.notif-row:last-of-type { border-bottom: none; }
.notif-info { flex: 1; padding-right: 16px; }
.notif-title { font-size: 14px; font-weight: 600; color: var(--ink); }
.notif-desc  { font-size: 12px; color: var(--ink-muted); margin-top: 2px; }
.toggle-wrap { position: relative; width: 40px; height: 22px; flex-shrink: 0; }
.toggle-wrap input { opacity: 0; width: 0; height: 0; position: absolute; }
.toggle-track {
  position: absolute; inset: 0;
  background: var(--cream-dark); border-radius: 99px;
  cursor: pointer; transition: background 0.2s;
  border: 1.5px solid var(--border-med);
}
.toggle-track::before {
  content: ''; position: absolute;
  width: 16px; height: 16px; top: 1px; left: 1px;
  background: white; border-radius: 50%;
  transition: transform 0.2s;
  box-shadow: 0 1px 4px rgba(0,0,0,0.18);
}
.toggle-wrap input:checked + .toggle-track { background: var(--terracotta); border-color: var(--terracotta); }
.toggle-wrap input:checked + .toggle-track::before { transform: translateX(18px); }

/* ── Appearance ───────────────────────────────────────── */
.theme-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 12px; }
.theme-opt {
  display: flex; flex-direction: column; align-items: center; gap: 8px;
  padding: 16px 10px; border-radius: var(--radius-sm);
  border: 1.5px solid var(--border); cursor: pointer;
  font-size: 13px; font-weight: 600; color: var(--ink-soft);
  background: var(--cream); transition: all 0.15s;
  font-family: 'Nunito', sans-serif;
}
.theme-opt i { font-size: 24px; }
.theme-opt:hover { border-color: var(--terracotta); color: var(--terracotta); background: var(--peach); }
.theme-opt.selected {
  border-color: var(--terracotta); color: var(--terra-dark);
  background: var(--peach); font-weight: 700;
}
.font-range-row {
  display: flex; align-items: center; gap: 14px; margin-top: 10px;
}
.font-range-row input[type=range] {
  flex: 1; accent-color: var(--terracotta); height: 4px; cursor: pointer;
}
.font-size-a { font-size: 13px; color: var(--ink-muted); font-weight: 700; }
.font-size-b { font-size: 18px; color: var(--ink-muted); font-weight: 700; }
.font-size-val {
  font-family: 'Fraunces', serif; font-size: 20px;
  font-weight: 600; color: var(--terracotta); min-width: 42px; text-align: right;
}
.appear-divider { height: 1.5px; background: var(--border); margin: 18px 0; }

/* ── Quiz history stats ───────────────────────────────── */
.hist-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; margin-bottom: 18px; }
.hist-stat {
  background: var(--cream-dark);
  border-radius: var(--radius-sm); padding: 16px 18px;
}
.hist-stat-num  { font-family: 'Fraunces', serif; font-size: 30px; font-weight: 600; color: var(--terracotta); line-height: 1; margin-bottom: 4px; }
.hist-stat-label { font-size: 12px; color: var(--ink-muted); font-weight: 600; }

/* ── Danger zone ──────────────────────────────────────── */
.danger-zone {
  border: 1.5px solid rgba(212,96,122,0.25);
  border-radius: var(--radius-sm); padding: 18px 20px;
  background: var(--rose-bg); margin-top: 6px;
}
.danger-zone-label {
  font-size: 10px; font-weight: 800; color: var(--rose);
  letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 12px;
}
.danger-row { display: flex; align-items: center; justify-content: space-between; gap: 16px; }
.danger-info { font-size: 14px; font-weight: 600; color: var(--ink); }
.danger-desc { font-size: 12px; color: var(--ink-muted); margin-top: 2px; }

/* ── Flash alert ──────────────────────────────────────── */
.flash-bar {
  padding: 11px 20px; border-radius: var(--radius-sm);
  font-size: 13.5px; font-weight: 600; margin-bottom: 18px;
  display: flex; align-items: center; gap: 9px;
}
.flash-success { background: var(--sage-bg); color: var(--sage); border: 1.5px solid var(--sage-light); }
.flash-error   { background: var(--rose-bg); color: var(--rose); border: 1.5px solid rgba(212,96,122,0.3); }

/* ── Security divider row ─────────────────────────────── */
.security-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 0; border-top: 1.5px solid var(--border); margin-top: 4px;
}
.security-row-info { font-size: 14px; font-weight: 600; color: var(--ink); }
.security-row-desc { font-size: 12px; color: var(--ink-muted); margin-top: 2px; }

/* ── User bar ─────────────────────────────────────────── */
.user-bar {
  display: flex; align-items: center; gap: 10px;
  padding: 12px 16px; background: rgba(255,255,255,0.15);
  border-radius: 10px; margin: 12px;
  border: 1px solid rgba(255,255,255,0.25);
}
.user-bar-avatar {
  width: 34px; height: 34px; border-radius: 50%;
  background: rgba(255,255,255,0.3);
  display: flex; align-items: center; justify-content: center;
  font-size: 14px; font-weight: 800; color: white;
  text-transform: uppercase; flex-shrink: 0;
}
.user-bar-info { flex: 1; min-width: 0; }
.user-bar-name { font-size: 13px; font-weight: 700; color: white; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.user-bar-role { font-size: 10.5px; color: rgba(255,255,255,0.7); }
.logout-btn {
  background: none; border: none; cursor: pointer;
  color: rgba(255,255,255,0.75); font-size: 18px;
  padding: 4px; border-radius: 6px; transition: all .15s;
  display: flex; align-items: center;
}
.logout-btn:hover { color: white; background: rgba(255,255,255,0.15); }
</style>
</head>
<body>

<div class="settings-shell">

  <!-- ══════════ SETTINGS SIDEBAR ══════════ -->
  <aside class="settings-sidebar">
    <div class="sidebar-header">
      <div class="logo-wrap" style="position:relative;z-index:1;">
        <span class="logo-emoji">📚</span>
        <div class="logo-name">StudyFlow</div>
        <div class="logo-tagline">Your academic companion</div>
      </div>
    </div>

    <div class="user-bar">
      <div class="user-bar-avatar"><?= h($initials) ?></div>
      <div class="user-bar-info">
        <div class="user-bar-name"><?= $displayName ?></div>
        <div class="user-bar-role">Student</div>
      </div>
      <a href="logout.php" class="logout-btn" title="Sign out">
        <i class="ti ti-logout"></i>
      </a>
    </div>

    <nav class="settings-nav">
      <button class="settings-nav-item active" onclick="switchTab('profile', this)">
        <i class="ti ti-user"></i> Profile
      </button>
      <button class="settings-nav-item" onclick="switchTab('security', this)">
        <i class="ti ti-lock"></i> Account &amp; security
      </button>
      <button class="settings-nav-item" onclick="switchTab('notifications', this)">
        <i class="ti ti-bell"></i> Notifications
      </button>
      <button class="settings-nav-item" onclick="switchTab('appearance', this)">
        <i class="ti ti-palette"></i> Appearance
      </button>
      <button class="settings-nav-item" onclick="switchTab('history', this)">
        <i class="ti ti-clock"></i> Quiz history
      </button>
      <div class="settings-nav-divider"></div>
      <a href="index.php" class="settings-nav-item">
        <i class="ti ti-arrow-left"></i> Back to dashboard
      </a>
    </nav>
  </aside>

  <!-- ══════════ MAIN PANEL ══════════ -->
  <main class="settings-main">
    <div class="settings-topbar">
      <a href="index.php" class="back-btn">
        <i class="ti ti-arrow-left" style="font-size:15px"></i> Dashboard
      </a>
      <div class="settings-topbar-title">Settings</div>
    </div>

    <div class="settings-body">

      <?php if ($flash): ?>
      <div class="flash-bar flash-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>">
        <i class="ti ti-<?= $flash['type'] === 'success' ? 'circle-check' : 'alert-circle' ?>"
           style="font-size:17px"></i>
        <?= h($flash['msg']) ?>
      </div>
      <?php endif; ?>

      <!-- ════════════════════════════════
           TAB: PROFILE
      ════════════════════════════════ -->
      <div class="settings-tab active" id="tab-profile">
        <div class="tab-heading">Profile</div>
        <div class="tab-sub">Manage your display name and personal info.</div>

        <div class="s-card">
          <div class="profile-row">
            <div class="profile-avatar"><?= h($initials) ?></div>
            <div>
              <div class="profile-name"><?= $displayName ?></div>
              <div class="profile-meta">
                Student &nbsp;·&nbsp;
                <span class="role-badge">User</span>
              </div>
            </div>
          </div>

          <div class="s-card-label">Personal info</div>
          <form method="POST" action="settings.php">
            <input type="hidden" name="action" value="save_profile">
            <?php
              $nameParts = explode(' ', trim($user['full_name']), 2);
              $firstName = $nameParts[0] ?? '';
              $lastName  = $nameParts[1] ?? '';
            ?>
            <div class="s-form-row">
              <div class="s-field">
                <label>First name</label>
                <input type="text" name="first_name" value="<?= h($firstName) ?>"
                       placeholder="First name" required maxlength="50">
              </div>
              <div class="s-field">
                <label>Last name</label>
                <input type="text" name="last_name" value="<?= h($lastName) ?>"
                       placeholder="Last name" maxlength="50">
              </div>
            </div>
            <div class="s-field">
              <label>Email address</label>
              <input type="email" name="email" value="<?= h($user['email']) ?>"
                     placeholder="you@example.com" required maxlength="180">
            </div>
            <div class="s-btn-row">
              <button type="submit" class="s-btn s-btn-primary">
                <i class="ti ti-device-floppy"></i> Save changes
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- ════════════════════════════════
           TAB: ACCOUNT & SECURITY
      ════════════════════════════════ -->
      <div class="settings-tab" id="tab-security">
        <div class="tab-heading">Account &amp; security</div>
        <div class="tab-sub">Update your password and manage active sessions.</div>

        <div class="s-card">
          <div class="s-card-label">Change password</div>
          <form method="POST" action="settings.php">
            <input type="hidden" name="action" value="change_password">
            <div class="s-field">
              <label>Current password</label>
              <input type="password" name="current_password" placeholder="Enter current password" required>
            </div>
            <div class="s-form-row">
              <div class="s-field">
                <label>New password</label>
                <input type="password" name="new_password" placeholder="At least 8 characters" required minlength="8">
              </div>
              <div class="s-field">
                <label>Confirm new password</label>
                <input type="password" name="confirm_password" placeholder="Repeat new password" required>
              </div>
            </div>
            <div class="s-btn-row">
              <button type="submit" class="s-btn s-btn-primary">
                <i class="ti ti-lock-check"></i> Update password
              </button>
            </div>
          </form>
        </div>

        <div class="s-card">
          <div class="security-row">
            <div>
              <div class="security-row-info">Sign out of all devices</div>
              <div class="security-row-desc">Ends all active sessions except this one.</div>
            </div>
            <form method="POST" action="settings.php" style="flex-shrink:0">
              <input type="hidden" name="action" value="signout_all">
              <button type="submit" class="s-btn">
                <i class="ti ti-devices-off"></i> Sign out all
              </button>
            </form>
          </div>
        </div>
      </div>

      <!-- ════════════════════════════════
           TAB: NOTIFICATIONS
      ════════════════════════════════ -->
      <div class="settings-tab" id="tab-notifications">
        <div class="tab-heading">Notifications</div>
        <div class="tab-sub">Choose what alerts you receive from StudyFlow.</div>

        <div class="s-card">
          <form method="POST" action="settings.php">
            <input type="hidden" name="action" value="save_notifications">

            <div class="notif-row">
              <div class="notif-info">
                <div class="notif-title">Quiz results</div>
                <div class="notif-desc">Get notified when your quiz is graded.</div>
              </div>
              <label class="toggle-wrap">
                <input type="checkbox" name="notif_quiz_results"
                       <?= $prefs['notif_quiz_results'] ? 'checked' : '' ?>>
                <span class="toggle-track"></span>
              </label>
            </div>

            <div class="notif-row">
              <div class="notif-info">
                <div class="notif-title">New quiz alerts</div>
                <div class="notif-desc">Be the first to know when new quizzes are available.</div>
              </div>
              <label class="toggle-wrap">
                <input type="checkbox" name="notif_new_quizzes"
                       <?= $prefs['notif_new_quizzes'] ? 'checked' : '' ?>>
                <span class="toggle-track"></span>
              </label>
            </div>

            <div class="notif-row">
              <div class="notif-info">
                <div class="notif-title">Survey reminders</div>
                <div class="notif-desc">Periodic reminders to complete feedback surveys.</div>
              </div>
              <label class="toggle-wrap">
                <input type="checkbox" name="notif_surveys"
                       <?= $prefs['notif_surveys'] ? 'checked' : '' ?>>
                <span class="toggle-track"></span>
              </label>
            </div>

            <div class="s-btn-row" style="margin-top:16px">
              <button type="submit" class="s-btn s-btn-primary">
                <i class="ti ti-device-floppy"></i> Save preferences
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- ════════════════════════════════
           TAB: APPEARANCE
      ════════════════════════════════ -->
      <div class="settings-tab" id="tab-appearance">
        <div class="tab-heading">Appearance</div>
        <div class="tab-sub">Customise the look and feel of StudyFlow.</div>

        <form method="POST" action="settings.php">
          <input type="hidden" name="action" value="save_appearance">
          <input type="hidden" name="theme" id="theme-input" value="<?= h($prefs['theme']) ?>">

          <div class="s-card">
            <div class="s-card-label">Theme</div>
            <div class="theme-grid">
              <button type="button" class="theme-opt <?= $prefs['theme']==='light' ? 'selected':'' ?>"
                      onclick="selectTheme('light', this)">
                <i class="ti ti-sun"></i> Light
              </button>
              <button type="button" class="theme-opt <?= $prefs['theme']==='dark' ? 'selected':'' ?>"
                      onclick="selectTheme('dark', this)">
                <i class="ti ti-moon"></i> Dark
              </button>
              <button type="button" class="theme-opt <?= $prefs['theme']==='system' ? 'selected':'' ?>"
                      onclick="selectTheme('system', this)">
                <i class="ti ti-device-laptop"></i> System
              </button>
            </div>
          </div>

          <div class="s-card">
            <div class="s-card-label">Font size</div>
            <div class="font-range-row">
              <span class="font-size-a">A</span>
              <input type="range" id="font-range" name="font_size"
                     min="12" max="20" step="1"
                     value="<?= (int)$prefs['font_size'] ?>"
                     oninput="document.getElementById('font-size-val').textContent = this.value + 'px'">
              <span class="font-size-b">A</span>
              <span class="font-size-val" id="font-size-val"><?= (int)$prefs['font_size'] ?>px</span>
            </div>
          </div>

          <div class="s-card">
            <div class="notif-row" style="border:none; padding:0;">
              <div class="notif-info">
                <div class="notif-title">Show quiz timer</div>
                <div class="notif-desc">Display a countdown during quizzes.</div>
              </div>
              <label class="toggle-wrap">
                <input type="checkbox" name="show_timer"
                       <?= $prefs['show_timer'] ? 'checked' : '' ?>>
                <span class="toggle-track"></span>
              </label>
            </div>
          </div>

          <div class="s-btn-row">
            <button type="submit" class="s-btn s-btn-primary">
              <i class="ti ti-device-floppy"></i> Save appearance
            </button>
          </div>
        </form>
      </div>

      <!-- ════════════════════════════════
           TAB: QUIZ HISTORY
      ════════════════════════════════ -->
      <div class="settings-tab" id="tab-history">
        <div class="tab-heading">Quiz history</div>
        <div class="tab-sub">Review your past performance and manage your task data.</div>

        <div class="s-card">
          <div class="s-card-label">Summary</div>
          <div class="hist-stats">
            <div class="hist-stat">
              <div class="hist-stat-num"><?= $totalTasks ?></div>
              <div class="hist-stat-label">Tasks created</div>
            </div>
            <div class="hist-stat">
              <div class="hist-stat-num"><?= $doneTasks ?></div>
              <div class="hist-stat-label">Completed</div>
            </div>
            <div class="hist-stat">
              <div class="hist-stat-num"><?= $completionRate ?>%</div>
              <div class="hist-stat-label">Completion rate</div>
            </div>
          </div>

          <div style="margin-top:4px">
            <a href="settings.php?export=csv" class="s-btn" style="text-decoration:none; display:inline-flex;">
              <i class="ti ti-download"></i> Export as CSV
            </a>
          </div>
        </div>

        <div class="danger-zone">
          <div class="danger-zone-label">⚠ Danger zone</div>
          <div class="danger-row">
            <div>
              <div class="danger-info">Clear all task history</div>
              <div class="danger-desc">Permanently deletes every task. This cannot be undone.</div>
            </div>
            <form method="POST" action="settings.php"
                  onsubmit="return confirm('Are you sure? This will permanently delete all your tasks.')">
              <input type="hidden" name="action" value="clear_history">
              <button type="submit" class="s-btn s-btn-danger">
                <i class="ti ti-trash"></i> Clear history
              </button>
            </form>
          </div>
        </div>
      </div>

    </div><!-- /settings-body -->
  </main>

</div><!-- /settings-shell -->

<?php
// ── CSV export (happens before any output — handled here since
//    PHP output has already started; redirect via JS) ───────
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $rows = $pdo->prepare(
        'SELECT t.title, t.type, t.due_date, t.priority, t.is_done, t.notes,
                c.name AS class_name
         FROM tasks t
         LEFT JOIN classes c ON t.class_id = c.id
         WHERE t.user_id = ?
         ORDER BY t.due_date ASC'
    );
    $rows->execute([$userId]);
    $csvData = $rows->fetchAll();

    // Output CSV via a data URI trick (headers already sent)
    $csv = "Title,Type,Due Date,Priority,Done,Class,Notes\n";
    foreach ($csvData as $r) {
        $csv .= implode(',', array_map(function($v) {
            return '"' . str_replace('"', '""', $v ?? '') . '"';
        }, [
            $r['title'], $r['type'], $r['due_date'], $r['priority'],
            $r['is_done'] ? 'Yes' : 'No', $r['class_name'] ?? '', $r['notes'] ?? ''
        ])) . "\n";
    }
    $encoded = base64_encode($csv);
    echo "<script>
      const a = document.createElement('a');
      a.href = 'data:text/csv;base64,{$encoded}';
      a.download = 'studyflow_tasks.csv';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    </script>";
}
?>

<script>
// ── Tab switching ──────────────────────────────────────────
function switchTab(name, btn) {
    document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.settings-nav-item').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    btn.classList.add('active');
    // Remove flash when switching tabs
    const flash = document.querySelector('.flash-bar');
    if (flash) flash.style.display = 'none';
}

// ── Auto-open tab from flash ───────────────────────────────
<?php if ($flash && !empty($flash['tab'])): ?>
(function() {
    const target = '<?= h($flash['tab']) ?>';
    const btn = document.querySelector(`[onclick="switchTab('${target}', this)"]`);
    if (btn) switchTab(target, btn);
})();
<?php endif; ?>

// ── Theme selector ─────────────────────────────────────────
function selectTheme(value, el) {
    document.querySelectorAll('.theme-opt').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    document.getElementById('theme-input').value = value;
}

// ── Reconstruct full_name from split first/last fields ─────
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function() {
        const first = this.querySelector('[name=first_name]');
        const last  = this.querySelector('[name=last_name]');
        if (first && last) {
            const hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = 'full_name';
            hidden.value = (first.value.trim() + ' ' + last.value.trim()).trim();
            this.appendChild(hidden);
        }
    });
});
</script>

</body>
</html>
