# StudyFlow — Flask Version

## How to Run

### Step 1 — Import the database
```bash
mysql -u root -p < sql/studyflow.sql
```
Or use phpMyAdmin: Import → select `sql/studyflow.sql` → Go.

### Step 2 — Edit your DB password (if needed)
Open `config.py` and set `DB_PASS` to your MySQL password.

### Step 3 — Create a virtual environment
```bash
python -m venv venv
```

### Step 4 — Activate it
**Windows:**
```
venv\Scripts\activate
```
**Mac/Linux:**
```
source venv/bin/activate
```

### Step 5 — Install packages
```bash
pip install -r requirements.txt
```

### Step 6 — Run the app
```bash
python app.py
```

### Step 7 — Open your browser
Go to: **http://localhost:5000**

---

## Project Structure
```
studyflow-flask/
├── app.py              ← entry point
├── config.py           ← DB credentials
├── extensions.py       ← Flask extensions
├── models.py           ← database models
├── requirements.txt
├── routes/
│   ├── auth.py         ← login, register, logout, forgot-password
│   └── main.py         ← dashboard + all API actions
├── templates/
│   ├── login.html
│   ├── register.html
│   ├── forgot_password.html
│   └── index.html
├── static/
│   ├── css/style.css
│   └── js/app.js
└── sql/
    └── studyflow.sql
```
