from datetime import datetime
from extensions import db, login_manager
from flask_login import UserMixin


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id         = db.Column(db.Integer, primary_key=True)
    full_name  = db.Column(db.String(100), nullable=False)
    email      = db.Column(db.String(180), unique=True, nullable=False)
    password   = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    classes = db.relationship('Class', backref='owner', lazy=True,
                              cascade='all, delete-orphan')
    tasks   = db.relationship('Task',  backref='owner', lazy=True,
                              cascade='all, delete-orphan')


class Class(db.Model):
    __tablename__ = 'classes'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name       = db.Column(db.String(120), nullable=False)
    code       = db.Column(db.String(20),  nullable=False)
    color      = db.Column(db.String(10),  default='#5B9BD5')
    prof       = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    tasks = db.relationship('Task', backref='cls', lazy=True)


class Task(db.Model):
    __tablename__ = 'tasks'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    class_id   = db.Column(db.Integer, db.ForeignKey('classes.id'), nullable=True)
    title      = db.Column(db.String(255), nullable=False)
    type       = db.Column(db.String(20),  default='assignment')
    due_date   = db.Column(db.Date,        nullable=False)
    priority   = db.Column(db.String(10),  default='medium')
    notes      = db.Column(db.Text)
    is_done    = db.Column(db.Boolean,     default=False)
    created_at = db.Column(db.DateTime,    default=datetime.utcnow)
    updated_at = db.Column(db.DateTime,    default=datetime.utcnow, onupdate=datetime.utcnow)
