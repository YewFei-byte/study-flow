class Config:
    # ── Edit these to match your MySQL setup ──────────────────
    DB_USER = 'root'
    DB_PASS = ''          # your MySQL password
    DB_HOST = 'localhost'
    DB_NAME = 'studyflow'

    SQLALCHEMY_DATABASE_URI = (
        f'mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}/{DB_NAME}'
        '?charset=utf8mb4'
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'studyflow-secret-key-change-in-production'
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Strict'
