from flask import Blueprint, render_template, redirect, url_for, request, flash, session
from flask_login import login_user, logout_user, login_required, current_user
from extensions import db, bcrypt
from models import User, Class

auth_bp = Blueprint('auth', __name__)


# ── Login ─────────────────────────────────────────────────────────────────────
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))

    error = ''
    old   = {'email': ''}

    if request.method == 'POST':
        email    = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        old      = {'email': email}

        if not email or not password:
            error = 'Please enter your email and password.'
        else:
            user = User.query.filter_by(email=email).first()
            if user and bcrypt.check_password_hash(user.password, password):
                login_user(user, remember=bool(request.form.get('remember')))
                return redirect(url_for('main.index'))
            else:
                error = 'Incorrect email or password. Please try again.'

    registered = request.args.get('registered')
    return render_template('login.html', error=error, old=old, registered=registered)


# ── Register ──────────────────────────────────────────────────────────────────
@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))

    errors = {}
    old    = {'full_name': '', 'email': ''}

    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email     = request.form.get('email', '').strip()
        password  = request.form.get('password', '')
        confirm   = request.form.get('confirm', '')
        old       = {'full_name': full_name, 'email': email}

        # Validate
        if not full_name:
            errors['full_name'] = 'Please enter your full name.'
        elif len(full_name) > 100:
            errors['full_name'] = 'Name must be 100 characters or fewer.'

        if not email:
            errors['email'] = 'Please enter your email address.'
        elif '@' not in email or '.' not in email.split('@')[-1]:
            errors['email'] = 'Please enter a valid email address.'

        if len(password) < 8:
            errors['password'] = 'Password must be at least 8 characters.'

        if password != confirm:
            errors['confirm'] = 'Passwords do not match.'

        # Check duplicate email
        if not errors:
            if User.query.filter_by(email=email).first():
                errors['email'] = 'That email is already registered. Try logging in.'

        if not errors:
            hashed = bcrypt.generate_password_hash(password).decode('utf-8')
            user   = User(full_name=full_name, email=email, password=hashed)
            db.session.add(user)
            db.session.flush()   # get user.id before commit

            # Seed default classes
            default_classes = [
                ('Introduction to Programming', 'CS101',   '#5B9BD5'),
                ('Mathematics I',               'MATH101',  '#8B7EC8'),
                ('English Communication',       'ENG101',   '#6A8F6E'),
            ]
            for cname, ccode, ccolor in default_classes:
                db.session.add(Class(user_id=user.id, name=cname, code=ccode, color=ccolor))

            db.session.commit()
            login_user(user)
            return redirect(url_for('main.index'))

    return render_template('register.html', errors=errors, old=old)


# ── Logout ────────────────────────────────────────────────────────────────────
@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))


# ── Forgot Password ───────────────────────────────────────────────────────────
@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))

    step    = 1
    error   = ''
    success = ''
    old     = {'email': '', 'full_name': ''}

    # Step 1 — verify identity
    if request.method == 'POST' and 'verify' in request.form:
        email     = request.form.get('email', '').strip()
        full_name = request.form.get('full_name', '').strip()
        old       = {'email': email, 'full_name': full_name}

        if not email or not full_name:
            error = 'Please enter both your Gmail address and your full name.'
        elif not email.endswith('@gmail.com'):
            error = 'Only Gmail addresses (@gmail.com) are accepted.'
        else:
            user = User.query.filter(
                db.func.lower(User.email)     == email.lower(),
                db.func.lower(User.full_name) == full_name.lower()
            ).first()

            if user:
                session['reset_user_id'] = user.id
                session['reset_email']   = email
                step = 2
            else:
                error = 'No account found matching that Gmail address and name. Please check and try again.'

    # Step 2 — save new password
    elif request.method == 'POST' and 'reset' in request.form:
        new_password     = request.form.get('new_password', '')
        confirm_password = request.form.get('confirm_password', '')

        if not session.get('reset_user_id'):
            error = 'Session expired. Please start again.'
            step  = 1
        elif not new_password or not confirm_password:
            error = 'Please fill in both password fields.'
            step  = 2
        elif len(new_password) < 8:
            error = 'Password must be at least 8 characters.'
            step  = 2
        elif new_password != confirm_password:
            error = 'Passwords do not match. Please try again.'
            step  = 2
        else:
            user = User.query.get(session['reset_user_id'])
            if user:
                user.password = bcrypt.generate_password_hash(new_password).decode('utf-8')
                db.session.commit()
            session.pop('reset_user_id', None)
            session.pop('reset_email',   None)
            success = 'Your password has been updated! You can now sign in with your new password.'
            step    = 1

    # Keep step 2 visible after a failed step-2 POST
    elif session.get('reset_user_id'):
        step = 2

    return render_template('forgot_password.html',
                           step=step, error=error, success=success, old=old)
