import json
from datetime import date
from flask import Blueprint, render_template, request, jsonify, session
from flask_login import login_required, current_user
from extensions import db, bcrypt
from models import Class, Task, User

main_bp = Blueprint('main', __name__)


# ── Dashboard ─────────────────────────────────────────────────────────────────
@main_bp.route('/')
@login_required
def index():
    classes = (Class.query
               .filter_by(user_id=current_user.id)
               .order_by(Class.name)
               .all())
    tasks = (Task.query
             .filter_by(user_id=current_user.id)
             .order_by(Task.due_date.asc())
             .all())

    # Build the same JSON structures app.js expects
    db_classes = [
        {
            'id':    str(c.id),
            'name':  c.name,
            'code':  c.code,
            'color': c.color,
            'prof':  c.prof or '',
        }
        for c in classes
    ]

    db_tasks = []
    for t in tasks:
        cls = Class.query.get(t.class_id) if t.class_id else None
        db_tasks.append({
            'id':        str(t.id),
            'title':     t.title,
            'subject':   str(t.class_id) if t.class_id else '',
            'type':      t.type,
            'due':       t.due_date.strftime('%Y-%m-%d'),
            'priority':  t.priority,
            'notes':     t.notes or '',
            'done':      bool(t.is_done),
            'createdAt': int(t.created_at.timestamp() * 1000),
            'class_name':  cls.name  if cls else '',
            'class_code':  cls.code  if cls else '',
            'class_color': cls.color if cls else '',
        })

    current_user_data = {
        'id':    current_user.id,
        'name':  current_user.full_name,
        'email': current_user.email or '',
    }

    return render_template('index.html',
                           user_name=current_user.full_name,
                           user_email=current_user.email or '',
                           db_classes=json.dumps(db_classes),
                           db_tasks=json.dumps(db_tasks),
                           current_user_json=json.dumps(current_user_data))


# ── Settings page ─────────────────────────────────────────────────────────────
@main_bp.route('/settings')
@login_required
def settings():
    total_tasks  = Task.query.filter_by(user_id=current_user.id).count()
    done_tasks   = Task.query.filter_by(user_id=current_user.id, is_done=True).count()
    high_pri_done = Task.query.filter_by(user_id=current_user.id, is_done=True, priority='high').count()
    completion_rate = round((done_tasks / total_tasks) * 100) if total_tasks else 0

    flash_msg = session.pop('flash', None)

    return render_template('settings.html',
                           user=current_user,
                           total_tasks=total_tasks,
                           done_tasks=done_tasks,
                           high_pri_done=high_pri_done,
                           completion_rate=completion_rate,
                           flash=flash_msg)


# ── API — all CRUD actions ────────────────────────────────────────────────────
@main_bp.route('/api.php', methods=['POST'])
@main_bp.route('/api',     methods=['POST'])
@login_required
def api():
    body   = request.get_json(silent=True) or {}
    action = body.get('action', '')
    uid    = current_user.id

    try:
        # ── add_task ──────────────────────────────────────────────────────────
        if action == 'add_task':
            title    = body.get('title', '').strip()
            due_date = body.get('due_date', '')
            if not title or not due_date:
                return jsonify({'ok': False, 'error': 'Missing required fields'})

            class_id = body.get('class_id') or None
            if class_id:
                class_id = int(class_id)
                if not Class.query.filter_by(id=class_id, user_id=uid).first():
                    class_id = None

            task = Task(
                user_id  = uid,
                class_id = class_id,
                title    = title,
                type     = body.get('type', 'assignment'),
                due_date = due_date,
                priority = body.get('priority', 'medium'),
                notes    = body.get('notes', '').strip(),
            )
            db.session.add(task)
            db.session.commit()
            return jsonify({'ok': True, 'id': task.id})

        # ── toggle_task ───────────────────────────────────────────────────────
        if action == 'toggle_task':
            task = Task.query.filter_by(id=body.get('id'), user_id=uid).first()
            if not task:
                return jsonify({'ok': False, 'error': 'Task not found'})
            task.is_done = bool(body.get('is_done', False))
            db.session.commit()
            return jsonify({'ok': True})

        # ── edit_task ─────────────────────────────────────────────────────────
        if action == 'edit_task':
            task = Task.query.filter_by(id=body.get('id'), user_id=uid).first()
            if not task:
                return jsonify({'ok': False, 'error': 'Task not found'})
            title    = body.get('title', '').strip()
            due_date = body.get('due_date', '')
            if not title or not due_date:
                return jsonify({'ok': False, 'error': 'Missing required fields'})
            class_id = body.get('class_id') or None
            if class_id:
                class_id = int(class_id)
                if not Class.query.filter_by(id=class_id, user_id=uid).first():
                    class_id = None
            task.class_id = class_id
            task.title    = title
            task.type     = body.get('type', 'assignment')
            task.due_date = due_date
            task.priority = body.get('priority', 'medium')
            task.notes    = body.get('notes', '').strip()
            db.session.commit()
            return jsonify({'ok': True})

        # ── delete_task ───────────────────────────────────────────────────────
        if action == 'delete_task':
            task = Task.query.filter_by(id=body.get('id'), user_id=uid).first()
            if task:
                db.session.delete(task)
                db.session.commit()
            return jsonify({'ok': True})

        # ── add_class ─────────────────────────────────────────────────────────
        if action == 'add_class':
            name = body.get('name', '').strip()
            code = body.get('code', '').strip()
            if not name:
                return jsonify({'ok': False, 'error': 'Name required'})
            if not code:
                code = name[:6].upper()
            cls = Class(
                user_id = uid,
                name    = name,
                code    = code,
                color   = body.get('color', '#5B9BD5'),
                prof    = body.get('prof', '').strip() or None,
            )
            db.session.add(cls)
            db.session.commit()
            return jsonify({'ok': True, 'id': cls.id})

        # ── delete_class ──────────────────────────────────────────────────────
        if action == 'delete_class':
            cls = Class.query.filter_by(id=body.get('id'), user_id=uid).first()
            if cls:
                db.session.delete(cls)
                db.session.commit()
            return jsonify({'ok': True})

        # ── update_name (called from settings in app.js) ──────────────────────
        if action == 'update_name':
            name = body.get('name', '').strip()
            if not name or len(name) > 100:
                return jsonify({'ok': False, 'error': 'Invalid name'})
            current_user.full_name = name
            db.session.commit()
            return jsonify({'ok': True})

        # ── update_email ──────────────────────────────────────────────────────
        if action == 'update_email':
            email = body.get('email', '').strip()
            if not email:
                return jsonify({'ok': False, 'error': 'Email required'})
            existing = User.query.filter(User.email == email, User.id != uid).first()
            if existing:
                return jsonify({'ok': False, 'error': 'Email already in use'})
            current_user.email = email
            db.session.commit()
            return jsonify({'ok': True})

        # ── change_password ───────────────────────────────────────────────────
        if action == 'change_password':
            old_pw = body.get('old_password', '')
            new_pw = body.get('new_password', '')
            if not bcrypt.check_password_hash(current_user.password, old_pw):
                return jsonify({'ok': False, 'error': 'Current password is incorrect'})
            if len(new_pw) < 8:
                return jsonify({'ok': False, 'error': 'Password must be at least 8 characters'})
            current_user.password = bcrypt.generate_password_hash(new_pw).decode('utf-8')
            db.session.commit()
            return jsonify({'ok': True})

        return jsonify({'ok': False, 'error': 'Unknown action'}), 400

    except Exception as e:
        db.session.rollback()
        return jsonify({'ok': False, 'error': 'Server error'}), 500
